<?php

/**
 * PH35 サンプル4 無名関数 Src07/09
 * 組み込み関数のコールバック。
 *
 * @author Shinzo SAITO
 *
 * ファイル名=useArrayMapAndTrim.php
 * フォルダ=/ph35/closure/
 */
// ↓配列の各要素に関して、文字列の前後に半角空白が何個か含まれている点に注意!
$params = [" 齊藤 ", " 新三 ", " プログラマ "];
print("<pre>");
var_dump($params);
print("</pre>");
$trimedParams = array_map("trim", $params);
print("<pre>");
var_dump($trimedParams);
print("</pre>");
