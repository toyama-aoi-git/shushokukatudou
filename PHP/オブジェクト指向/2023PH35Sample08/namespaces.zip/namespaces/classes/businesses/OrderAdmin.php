<?php

/**
 * PH35 サンプル8 名前空間 Src02/08
 * 名前空間がない場合
 *
 * @author Shinzo SAITO
 *
 * ファイル名=OrderAdmin.php
 * フォルダ=/ph35/namespaces/classes/businesses/
 */
class OrderAdmin
{
    public function __construct()
    {
        print("businesses/OrderAdminがnewされました<br>");
    }
}
