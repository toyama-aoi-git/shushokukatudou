<?php

/**
 * PH35 サンプル8 名前空間 Src05/08
 * 名前空間とは
 *
 * @author Shinzo SAITO
 *
 * ファイル名=MainController.php
 * フォルダ=/ph35/namespaces/classes/
 */

namespace LocalHalPH35\Namespaces\classes;

class MainController
{
    public function __construct()
    {
        print("MainControllerがnewされました<br>");
    }
}
