<?php
/**
 * PH35 サンプル3 マスタテーブル管理 Src04/12
 * 
 * @author Shinzo SAITO
 * 
 * ファイル名=Conf.php
 * フォルダ=/scottadmin/classes/
 */

/**
 * 定数クラス
 */

 class Conf{
    const DB_DNS = "mysql:host=localhost;dbname=ph35scott;charset=utf8";
    const DB_USERNAME = "scott";
    const DB_PASSWORD = "tiger";
 }