<?php
    function get_max_id($file_path){
        $fp = fopen($file_path,'r');
        $id = 0;
        while($row = fgets($fp)){
            $data = explode(',',$row);
            if($id < $data[0]){
                $id = $data[0];
            }
        }
        fclose($fp);
        return $id; 
    }
    
    function append_csv($file_name , $data){
        $fp = fopen($file_name , 'a');
        fputs($fp , implode(',' , $data) . "\n");
        fclose($fp);
    }

    function write_csv($file_name , $data){
        $fp = fopen($file_name , 'w');
        fputs($fp , implode(',' , $data) . "\n");
        fclose($fp);
    }

    function null_data($data){
        if(strlen($data) == 0){
            
        }
    }

    function read_csv($file_path){
        //全件読み込み
        $fp = fopen($file_path,'r');
        $id = 0;
        while($row = fgets($fp)){
            $data[] = str_replace("\n","",explode(',',$row));
        }
        fclose($fp);

        //二次元配列に格納
        return $data;
    }

    function sql_action($host_name,$user_id,$password,$db_name,$sql){

        //更新系SQLぶっこみ
        $link = @mysqli_connect($host_name,$user_id,$password,$db_name);
        mysqli_set_charset($link,'utf8');
        if($link != false){
            mysqli_set_charset($link,'utf8');
            mysqli_query($link,$sql);
            mysqli_close($link);
        }else{
        require_once'./view/err_view.html';
        exit;
        }
    }

    function insert_creater($table_name,$data){

        // 添え字を抽出
        $key_list = array_keys($data);

        // 文字列を作成
        for($i = 0;$i < count($key_list);$i++){
            $key_word = implode(',',$key_list);
        }

        // 配列の中身を文字列で作成
        for($i = 0;$i < count($data);$i++){
            $list = implode("','",$data);
        }

        
        $insert_sql = "INSERT INTO " . $table_name . "(" . $key_word . ") VALUES ('" . $list . "');";

        //insert文を返す
        return $insert_sql;
    }

    //件数を取得する 
    function number($host_name,$user_id,$password,$db_name,$tbl_name){
        //全件読み込み
        $num = 0;

        $link = @mysqli_connect($host_name,$user_id,$password,$db_name);
        mysqli_set_charset($link,'utf8');
        $result = mysqli_query($link,"SELECT count(id) FROM $tbl_name;");
        while($row = mysqli_fetch_assoc($result)){
            $data[] = $row;
        }

        // $num1 = mysqli_fetch_assoc($result);
        mysqli_close($link);


            

        //二次元配列に格納
        return $data;   
    }

    
    // DBを読み込む
    function func05($host_name,$user_id,$password,$db_name,$tbl_name){
        //全件読み込み
        $link = @mysqli_connect($host_name,$user_id,$password,$db_name);
        mysqli_set_charset($link,'utf8');
        $result = mysqli_query($link,"SELECT * FROM $tbl_name;");
        while($row = mysqli_fetch_assoc($result)){
            $data[] = $row;
        }
        mysqli_close($link);
            

        //二次元配列に格納
        return $data;
    }

    // 最大のIDを取得(PHPの関数であるから調べて直す)
        function id_action($host_name,$user_id,$password,$db_name,$table_name){
        $link = @mysqli_connect($host_name,$user_id,$password,$db_name);
        mysqli_set_charset($link,'utf8');
            $sql = "SELECT last_insert_id() FROM $table_name";
            $result = mysqli_query($link,$sql);
            $data = mysqli_fetch_assoc($result);
            $id = $data['max(id)'];
            mysqli_close($link);

            return $id;
    }

        // DBを読み込む(降順)
        function DESC($host_name,$user_id,$password,$db_name,$tbl_name,$cal){
            //全件読み込み
            $link = @mysqli_connect($host_name,$user_id,$password,$db_name);
            mysqli_set_charset($link,'utf8');
            $result = mysqli_query($link,"SELECT * FROM $tbl_name ORDER BY $cal DESC;");
            while($row = mysqli_fetch_assoc($result)){
                $data[] = $row;
            }
            mysqli_close($link);
                
    
            //二次元配列に格納
            return $data;
        }

        //指定のデータを取得する
        function data($host_name,$user_id,$password,$db_name,$tbl_name,$sort_sorce,$sort,$start_num,$num2){
            //全件読み込み
            $num = 0;
    
            $link = @mysqli_connect($host_name,$user_id,$password,$db_name);
            mysqli_set_charset($link,'utf8');
            $result = mysqli_query($link,"select * from $tbl_name order by $sort_sorce $sort limit $start_num,$num2;");

        
            while($row = mysqli_fetch_assoc($result)){
                $data[] = $row;
            }
            mysqli_close($link);
    
                
    
            //二次元配列に格納
            return $data;   
        }


?>
