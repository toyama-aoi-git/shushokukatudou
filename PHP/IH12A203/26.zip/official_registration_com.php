<?php
    require_once 'tpl/official_registration_com.php';
?>