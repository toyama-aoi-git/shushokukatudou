<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <title>Document</title>
</head>
<body>

    <form action="entry.php" method="post">
        <h1>会員仮登録</h1>
        <p>氏名</p><input type="text" name="name" value="<?php echo isset($_POST['name'])?$_POST['name']:'';?><?php echo isset($_SESSION['name'])?$_SESSION['name']:'';?>"><p><?php echo isset($err_msg['name'])?$err_msg['name']:''; ?></p>
        <p>ログインID</p><input type="text" name="loginid" value="<?php echo isset($_POST['loginid'])?$_POST['loginid']:'';?><?php echo isset($_SESSION['loginid'])?$_SESSION['loginid']:'';?>"><p><?php echo isset($err_msg['loginid'])?$err_msg['loginid']:''; ?></p>
        <p>パスワード</p><input type="password" name="password" value=""><p><?php echo isset($err_msg['password'])?$err_msg['password']:''; ?></p>
        <p>メールアドレス</p><input type="text" name="mail_address" value="<?php echo isset($_POST['mail_address'])?$_POST['mail_address']:'';?><?php echo isset($_SESSION['mail_address'])?$_SESSION['mail_address']:'';?>"><p><?php echo isset($err_msg['mail_address'])?$err_msg['mail_address']:''; ?></p>
        <button type="submit" name="state" value="insert">確認画面へ</button>
    </form>
</body>
<script src="js/func.js"></script>
</html>