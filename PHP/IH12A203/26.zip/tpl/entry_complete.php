<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <title>Document</title>
</head>
<body>
    <p>仮登録完了メールを以下のメールアドレスに送信しました。</p>
    <p><?php echo $mail ?></p>
    <p>以下メール本文です。</p>
    <p>仮登録が完了しました。以下のリンクから本登録へ移行してください</p>
    <a href="<?php echo BASE_URL; ?>26/official_registration.php?id=<?php echo $id; ?>"><?php echo BASE_URL; ?>26/official_registration.php?id=<?php echo $id; ?></a>
</body>
<script src="js/func.js"></script>
</html>