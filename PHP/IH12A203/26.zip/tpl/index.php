<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <title>Document</title>
</head>
<body>
    <div class="header">
        <img src="<?php echo $thumb; ?>" alt="">
        <span><?php echo $data[0]['name']; ?></span>
        <form action="index.php" method="post">
            <button type="submit" name="state" value="logout">ログアウト</button>
        </form>
    </div>




    <div><!--該当データ表示-->
        <?php for($i=0;$i<$num2;$i++){?>
            <table class="contents">
                <?php for($i=0;$i<$num2;$i++){ ?>
                <tr>
                        <?php if(isset($news[0][$i]['id'])){?>
                        <td><a href="./data.php?id=<?php echo $news[0][$i]['id']; ?>"><?php echo $news[0][$i]['title']?></a></td>
                        <td><?php echo $news[0][$i]['created_at']?></td>
                        <?php } ?>
                </tr>
                <?php } ?>
            </table>
        <?php } ?>
    </div>
        <div class="page"><!--ページ下部-->
            <a href="?specify_num=<?php echo max($specify_num - 1,0); ?>" <?php if($specify_num == 0){echo 'class="no-link"';}?>>前へ</a>
            <?php for($i = 1;$i <= $max_page;$i++){ ?>
            <a href="?specify_num=<?php echo $i - 1; ?>" <?php if($i - 1 == $specify_num){echo 'class="no-link"';} ?>><?php echo $i; ?></a>  <!--ページ番号表示-->
            <?php } ?>
            <a href="?specify_num=<?php echo min($specify_num + 1,$max_page); ?>" <?php if($specify_num + 1 == $max_page){echo 'class="no-link"';}?>>次へ</a>
    </div>

</body>
<script src="js/func.js"></script>
</html>