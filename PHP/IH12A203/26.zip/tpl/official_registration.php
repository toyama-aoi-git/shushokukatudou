<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <title>Document</title>
</head>
<body>
    <form action="./official_registration.php" method="post" enctype="multipart/form-data">
        <label>氏名：</label><?php echo $name; ?><br>
        <label>パスワード：</label><input type="password" name="password"><p><?php echo isset($err_msg['password'])?$err_msg['password']:''; ?></p><br>
        <label for="">ファイル：</label><input type="file" name="upload-file" enctype="multipart/form-data"><p><?php echo isset($err_msg['img'])?$err_msg['img']:''; ?></p><br>
        <p>※画像の拡張子は.jpgのみ受け付けています</p>
        <input type="hidden" name=id value="<?php echo $id; ?>">
        <button type="submit" name="state" value="update">本登録</button>
    </form>
</body>
<script src="js/func.js"></script>
</html>