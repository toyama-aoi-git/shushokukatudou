<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <title>Document</title>
</head>
<body>



    <form action="login.php" method="post">
        <h1>ログイン</h1>
        <p><?php echo isset($err_msg['login'])?$err_msg['login']:''; ?></p>
        <p>ログインID</p><input type="text" name="loginid" value="<?php echo isset($_POST['loginid'])?$_POST['loginid']:'';?>">
        <p><?php echo isset($err_msg['loginid'])?$err_msg['loginid']:''; ?></p>
        <p>パスワード</p><input type="password" name="password" value="">
        <p><?php echo isset($err_msg['password'])?$err_msg['password']:''; ?></p>
        <button type="submit" name="state" value="insert">ログイン→</button>
    </form>

    <p>会員登録がまだの方はこちら</p>
    <a href="entry.php">仮会員登録画面へ</a>
</body>
</html>