
<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <title>Document</title>
</head>
<body>
    <h1>仮登録内容の確認</h1>
    <h2>こちらの内容で間違いないでしょうか？</h2>
    <form action="entry_comfirmation.php" method="post">
        <p>氏名：<?php echo $name ?></p>
        <p>ログインID：<?php echo $loginid; ?></p>
        <p>パスワード：<?php echo $view_password; ?></p>
        <p>メールアドレス：<?php echo $mail_address; ?></p>
        <button  type="submit" name="state" value="return">仮登録画面に戻る</button>
        <button  type="submit" name="state" value="insert">登録を確定する</button>
    </form>
</body>
</html>