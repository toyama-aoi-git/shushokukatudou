<?php
    const HOST = 'localhost';
    const USER_ID = 'root';
    const PASSWORD = '';
    const DB_NAME = 'memory';
    // const TABLE = 'msg';
    const PDF_DIR = '../../vendor/autoload.php';
    const BASE_URL = 'http://localhost/PH24/kadai/IH12A203/';
    const DIR_IMG = '../../img/';

?>