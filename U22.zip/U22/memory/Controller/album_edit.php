<?php
//更新　籾木
//version 0.0
require_once "../function/function.php";
require_once "../../config.php";

session_start();
// ログイン済みの時
if(isset($_COOKIE['id'])){
    // アルバムタイトルがあるとき
    // if(isset($_SESSION['title'])){
    //     unset($_SESSION['title']);
    // }
    // グループIDがない時
    if(!isset($_SESSION['group_id'])){
        header('location:./group_list.php');
        exit();
    }else{
        $sql = "SELECT e.id , e.name , e.comment , e.date
        FROM event e
        INNER JOIN list l
        ON e.id = l.event_id
        WHERE l.group_id = ".$_SESSION['group_id']."";
        $data = select(HOST,USER_ID,PASSWORD,DB_NAME,$sql);
        
        for($i=0;$i<COUNT($data);$i++){
            $sql = "SELECT * FROM event e INNER JOIN image i ON e.id = i.event_id INNER JOIN list l ON e.id = l.event_id WHERE i.event_id = '".$data[$i]['id']."'";
            $list['ext'][] = select(HOST,USER_ID,PASSWORD,DB_NAME,$sql);
        }
        
        // 年月の修正
        foreach ($data as $key => $value) {
            $date = explode('-',$value['date']);
            $data[$key]['date'] = (int)$date[0].'年'.(int)$date[1].'月'.(int)$date[2].'日';
        }
    }
}else{
    header('location:./OP.php');
    exit();
}

require_once "../view/album_edit.php";
?>