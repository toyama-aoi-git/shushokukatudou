<?php
    //更新　籾木
    //version 1 .0

    require_once "../../config.php";
    require_once "../function/function.php";

    session_start();

    if(isset($_SESSION['pre_id'])){
        setcookie("id", $_SESSION['pre_id'] , time() + 60 * 60 * 24);
        unset($_SESSION['pre_id']);
        header("location:group.php");
        exit;
    }

    // ログイン済みの時
    if(isset($_COOKIE['id'])){

        // イベント詳細
        if(isset($_GET['event_id'])){
            //やり方かえる
            $id = explode(',',$_GET['event_id']);
            $_SESSION['event_id'] = $id[0];
            $_SESSION['group_id'] = $id[1];
            $_SESSION['date'] = $id[2];
            header('location:./event_change.php');
            exit();
        }
        if(!$_SESSION['group_id']){
            header('location:./group_list.php');
            exit();
        }else{
            $json_group_id = json_encode($_SESSION['group_id']);
            // $_SESSION = array();
            // session_destroy();
        }
    }else{
        header('location:./OP.php');
        exit();
    }
    require_once "../view/group.php";
?>