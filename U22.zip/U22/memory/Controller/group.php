<?php
    //更新　籾木
    //version 1 .0

    require_once "../../config.php";
    require_once "../function/function.php";

    session_start();

    // ログイン済みの時
    if(isset($_COOKIE['id'])){

        //ここから新規
        $link = sql_start(HOST,USER_ID,PASSWORD,DB_NAME);
        $sql = "SELECT * FROM event e
                INNER JOIN list l
                ON e.id = l.event_id
                WHERE l.group_id = " . $_SESSION['group_id'];
        $result = mysqli_query($link , $sql);
        while($row = mysqli_fetch_assoc($result)){
            $list[] = $row;
        }

        if(!empty($list)){
            $eventList = [];
            foreach($list as $val){
                $event = [];
                if($val['end_date'] != $val['start_date']){ //複数日のイベント
                    $dayCount = 0;
                    for($i=date('Ymd', strtotime($val['start_date'])); $i<=date('Ymd', strtotime($val['end_date'])); $i++) {
                    $dayCount++; //何日目かの判定

                    ///イベントの日数を取得
                    $count = 0;
                    for($j=date('Ymd', strtotime($val['start_date'])); $j<=date('Ymd', strtotime($val['end_date'])); $j++){
                        $year = substr($j, 0,4);
                        $month = substr($j, 4,2);
                        $day = substr($j, 6,2);
                        $count++;
                    }
                    $year = substr($i, 0,4);
                    $month = substr($i, 4,2);
                    $day = substr($i, 6,2);
                    if(checkdate ( $month , $day , $year ))
                        $event['id'] = $val['id'];
                        $event['name'] = $val['name'];
                        $event['comment'] = $val['comment'];
                        $event['date'] = date('Y-m-d', strtotime($i));
                        $event['count'] = $dayCount;
                        $event['dateCount'] = $count;
                        $eventList[] = $event;
                    }
                } else { //1日だけのイベント
                    $event['id'] = $val['id'];
                    $event['name'] = $val['name'];
                    $event['comment'] = $val['comment'];
                    $event['date'] = $val['start_date'];
                    $event['count'] = "";
                    $event['dateCount'] = "";
                    $eventList[] = $event;
                }
            }
    }
        // イベント詳細
        if(isset($_GET['event_id'])){

            $_SESSION['event_id'] = $_GET['event_id'];
            $_SESSION['group_id'] = $_GET['group_id'];
            header('location:./event_change.php');
            exit();
        }
        if(!$_SESSION['group_id']){
            header('location:./group_list.php');
            exit();
        }else{
            $json_group_id = json_encode($_SESSION['group_id']);
            // $_SESSION = array();
            // session_destroy();
        }
    }else{
        header('location:./OP.php');
        exit();
    }
    require_once "../view/group.php";
?>