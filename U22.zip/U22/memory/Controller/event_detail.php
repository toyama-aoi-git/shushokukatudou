<?php
//更新　田中
//version 0.0

require_once "./view/event_detail.php";
?>