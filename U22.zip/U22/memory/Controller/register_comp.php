<?php
//更新　籾木
//version 0.0
require_once "../view/register_comp.php";
require_once "../../config.php";

// session_start();
setcookie('id',$_SESSION['id'],time()+60*60*24);
// var_dump($_COOKIE['id']);
// if(isset($_SESSION['mail'])){
//     // メール送信
//     mb_language("Japanese");
//     mb_internal_encoding("UTF-8");
//     $mailto = $_SESSION['mail'];
//     // タイトル（未定）
//     $title = '';
//     // メッセージ(未定)
//     $message = '';
//     $headers = "FROM:".FROM;
//     // @mb_send_mail($mailto,$title,$message,$headers);
// }
// $_SESSION = array();
// session_destroy();
?>