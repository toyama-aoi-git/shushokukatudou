<?php
//更新　籾木
//version 1.2
require_once '../../config.php';
require_once '../function/function.php';

// ajax
if(isset($_POST['name_b'])){
    $list = '';
    $sql = "SELECT * FROM member where name = '".$_POST['name_b']."' && password = '".$_POST['pass_b']."'";
    $list = select(HOST,USER_ID,PASSWORD,DB_NAME,$sql);

    // jsonとして出力
    header('Content-type: application/json');
    echo json_encode($list,JSON_UNESCAPED_UNICODE);
    exit();
}elseif(isset($_POST['name'])){
    $link = sql_start(HOST,USER_ID,PASSWORD,DB_NAME);
    if($_POST['bir'] != ''){
        $sql = "INSERT INTO member (name,birthday,password,withdrawal) 
        VALUES ('".$_POST['name']."','".$_POST['bir']."','".$_POST['pass']."',0)";
    }else{
        $sql = "INSERT INTO member (name,password,withdrawal) 
        VALUES ('".$_POST['name']."','".$_POST['pass']."',0)";
    }
    if($link != false){
        mysqli_query($link , $sql);
        // id取得
        $id = mysqli_insert_id($link);
        mysqli_close($link);
    
        // cookieの設定
        setcookie('id',$id,time()+60*60*24);

        // user内にフォルダの作成
        $img_link = '../user/'.$id;
        @mkdir($img_link);
        @mkdir($img_link.'/search_img');
        @mkdir($img_link.'/user_icon');
    }
    else{
        echo "データベースが悪い";
    }
    // jsonとして出力
    header('Content-type: application/json');
    echo json_encode($id,JSON_UNESCAPED_UNICODE);
    exit();
}

require_once "../view/register.php";

?>