<?php
//更新　籾木
//version 1.0

session_start();
$json_group_id = $_SESSION['group_id'];
$json_album_id = $_SESSION['album_id'];

require_once "../view/album_brow.php";
?>