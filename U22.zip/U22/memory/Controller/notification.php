<?php
//更新　田中
//version 0.0

require_once "../../config.php";
require_once "../function/function.php";


if(isset($_POST['id_0'])){
        
    foreach($_POST as $val){

        $delete[] = $val;
    }

    $delete_id = implode(' OR id = ' , $delete);
    // echo $delete_id;

    $sql = "DELETE FROM notification WHERE id = " . $delete_id;
    insert(HOST,USER_ID,PASSWORD,DB_NAME,$sql);
}

if(isset($_COOKIE['id'])){

    $member_id = $_COOKIE['id'];
    $list = [];
    $sql = "SELECT * FROM notification WHERE member_id = " . $member_id;
    $list = @select(HOST,USER_ID,PASSWORD, DB_NAME , $sql);

    if(empty($list)){
        $list[0]['not'] = "通知はありません";
    }

}




require_once "../view/notification.php";

?>