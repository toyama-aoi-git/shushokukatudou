<?php
//更新　籾木
//version 0.0
require_once "../function/function.php";
require_once "../../config.php";

session_start();
// ログイン済みの時
if(isset($_COOKIE['id'])){
    $json_group_id = json_encode($_SESSION['group_id']);
    $group_id = $_SESSION['group_id'];
    $ids = $_GET["id"];
    $sql = "SELECT i.id , i.extension , e.id AS 'event_id' FROM image i INNER JOIN event e ON i.event_id = e.id INNER JOIN list l ON e.id = l.event_id WHERE l.group_id = $group_id AND i.event_id IN ($ids);";
    $data = select(HOST,USER_ID,PASSWORD,DB_NAME,$sql);

    $ids = explode(',',$_GET["id"]);
    $num = 0;
    $page = $_GET["page"];
}else{
    header('location:./OP.php');
    exit();
}

require_once '../view/album_editor.php';
?>


