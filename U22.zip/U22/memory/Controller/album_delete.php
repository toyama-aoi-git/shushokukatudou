<?php
//更新　田中
//version 0.0

echo "aa";


?>