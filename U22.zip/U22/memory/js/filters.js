
var function_list = new Array();
// 初期化
function_list.normal_btn = function () {
    hexColor = $("#hex-color").val();
    Caman("#sourceCanvas", img, function () {
        this.revert();
    });
}

// フィルター系
// 1
function_list.vintage = function () {
    Caman("#sourceCanvas", img, function () {
        this.vintage().render();
    });
}
// 1
function_list.lomo = function () {
    Caman("#sourceCanvas", img, function () {
        this.lomo().render();
    });
}
// 1
function_list.clarity = function () {
    Caman("#sourceCanvas", img, function () {
        this.clarity().render();
    });
}
function_list.sinCity = function () {
    Caman("#sourceCanvas", img, function () {
        this.sinCity().render();
    });
}
// 1
function_list.sunrise = function () {
    Caman("#sourceCanvas", img, function () {
        this.sunrise().render();
    });
}
// 1
function_list.crossProcess = function () {
    Caman("#sourceCanvas", img, function () {
        this.crossProcess().render();
    });
}
// 1
function_list.orangePeel = function () {
    Caman("#sourceCanvas", img, function () {
        this.orangePeel().render();
    });
}
// 1
function_list.love = function () {
    Caman("#sourceCanvas", img, function () {
        this.love().render();
    });
}
// 1
function_list.grungy = function () {
    Caman("#sourceCanvas", img, function () {
        this.grungy().render();
    });
}
// 1
function_list.jarques = function () {
    Caman("#sourceCanvas", img, function () {
        this.jarques().render();
    });
}
// 1
function_list.pinhole = function () {
    Caman("#sourceCanvas", img, function () {
        this.pinhole().render();
    });
}
// 1
function_list.oldBoot = function () {
    Caman("#sourceCanvas", img, function () {
        this.oldBoot().render();
    });
}
// 1
function_list.glowingSun = function () {
    Caman("#sourceCanvas", img, function () {
        this.glowingSun().render();
    });
}
// 1
function_list.hazyDays = function () {
    Caman("#sourceCanvas", img, function () {
        this.hazyDays().render();
    });
}
// 1
function_list.herMajesty = function () {
    Caman("#sourceCanvas", img, function () {
        this.herMajesty().render();
    });
}
// 1
function_list.nostalgia = function () {
    Caman("#sourceCanvas", img, function () {
        this.nostalgia().render();
    });
}
// 1
function_list.hemingway = function () {
    Caman("#sourceCanvas", img, function () {
        this.hemingway().render();
    });
}
// 1
function_list.concentrate = function () {
    Caman("#sourceCanvas", img, function () {
        this.concentrate().render();
    });
}



// 動かない
function_list.blackAndWhite = function () {
    Caman("#sourceCanvas", img, function () {
        this.blackAndWhite().render();
    });
}
// 動かない
function_list.bright = function () {
    Caman("#sourceCanvas", img, function () {
        this.brightness().render();
    });
}





