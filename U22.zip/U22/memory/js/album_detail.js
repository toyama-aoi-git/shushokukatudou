$(function() {
    let iframe_height = window.parent.screen.width;
    let iframe_width = window.parent.screen.width / 30 * 40;
    $.when(
        // iframe
        $('#d_frame').css('height',300),
        $('#d_frame').css('width',400),
        $('#d_frame').css({transform: "scale(0.5) rotate(90deg)"}),
    ).done(function() {
        $('.modal-content').css('height',iframe_height * 0.8);
    })

    console.log(iframe_width);
    if(iframe_width <= 480){
        $('#d_frame').css('top','30%');
        $('.modal-content').css('top','24%');
        $('#d_frame').css('left','-5%');
        $('#d_frame').css({transform: "scale(1.15) rotate(90deg)"});
    }else if(iframe_width > 480 && iframe_width <= 500){
        console.log('OK');
        $('#d_frame').css('top','30%');
        $('.modal-content').css('top','24%');
        $('#d_frame').css('left','-3%');
        $('#d_frame').css({transform: "scale(1.15) rotate(90deg)"});
    }else if(iframe_width > 500 && iframe_width <= 515){
        console.log('OK');
        $('#d_frame').css('top','25%');
        $('.modal-content').css('top','25%');
        $('#d_frame').css({transform: "scale(1.23) rotate(90deg)"});
    }else if(iframe_width > 515 && iframe_width <= 530){
        console.log('OK');
        $('#d_frame').css('top','32%');
        $('#d_frame').css('left','-1%');
        $('.modal-content').css('top','24%');
        $('#d_frame').css({transform: "scale(1.25) rotate(90deg)"});
    }else if(iframe_width > 545 && iframe_width <= 560){
        console.log('OK');
        $('#d_frame').css('top','32%');
        $('.modal-content').css('top','27%');
        $('#d_frame').css('left','2%');
        $('#d_frame').css({transform: "scale(1.3) rotate(90deg)"});
    }else if(iframe_width > 560){
        $('#d_frame').css('top','28%');
        $('.modal-content').css('top','28%');
        $('#d_frame').css({transform: "scale(1.2) rotate(90deg)"});
    }
});