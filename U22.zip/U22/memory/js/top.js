//更新　籾木
//version 1.0

'use strict';
let group_id;
let text;
let member_id;
// 「年」の取得
let year = new Date().getFullYear();
// 「月」の取得
let month = new Date().getMonth() + 1;
let y;
let x;
// ロード時
window.onload = function (){
    // グループid
    console.log(js_php);
    group_id = js_php;

    $.ajax({
        type:'POST',
        url:'../js/top_ajax.php',
        data: {
            // グループidを送信
            load:group_id
        },
        cache:false
    })
    .done(function(data){
        console.log(data);
        // 年の取得
        year = data['date'].substr(0,4);

        //月の取得
        if(data['date'].substr(5,1) == 0){
            month = data['date'].substr(6,1);
        }else{
            month = data['date'].substr(5,2);
        }
        
        // 年・月の表示
        $('#year').append(year+"年"+month+"月");

        // グループ名の取得
        text = data['g_name'];
        
        //グループ名表示
        $("#group_name").append(text);
        create_html(data);
    })
}
// Swiper
var mySwiper = new Swiper(".swiper", {
    spaceBetween:10,
    slidesPerView:1,
    watchActiveIndex:true,
    initialSlide:1,
    touchRatio:0.3,
    centeredSlides:true,
    touchAngle: 20,
    on: {
        // 切り替わりのアニメーションが終了したとき
        slideChangeTransitionEnd: function(event) {
            N_swiper(event);
        }
    }
});

// スライド
function N_swiper(event){
    $('.swiper-slide-active').css('min-height',$(window).height());
    // 左から右　12月⇒11月⇒10月...
    if(event.activeIndex == 0){
        let day;
        $('.swiper').remove();
        $('.wrap').append(
            '<div class="event_contena swiper">'+
                '<div class="swiper-wrapper">'+
                    '<div  class="swiper-slide"></div>'+
                    '<div  class="swiper-slide"></div>'+
                    '<div  class="swiper-slide"></div>'+
                '</div>'+
            '</div>'
        );
        var mySwiper = new Swiper(".swiper",{	
            spaceBetween:10,
            slidesPerView:1,
            watchActiveIndex:true,
            initialSlide:1,
            touchRatio:0.3,
            centeredSlides:true,
            touchAngle: 20,
            on: {
                // 切り替わりのアニメーションが終了したとき
                slideChangeTransitionEnd: function(event) {
                    N_swiper(event);
                }
            }
        });
        if(month == 1){
            year = Number(year) - 1;
            month = 12;
            day = year+'-'+month;

            // headerの年月の更新
            $('#year').empty();
            $('#year').append(year+"年"+month+"月");

            // ajax通信（表示）
            $.ajax({
                type:'POST',
                url:'../js/top_ajax.php',
                data: {
                    // グループidを送信
                    group:group_id,
                    year:day
                },
                cache:false
            })
            .done(function(data){
                create_html(data);
            })
        }else{
                    
            month = Number(month) - 1;   
            // headerの年月の更新
            $('#year').empty();
            $('#year').append(year+"年"+month+"月");

            if(month != 11 && month != 10){
                let mon = '0'+month;
                day = year+'-'+mon;
            }else{
                day = year+'-'+ month;
            }

            // ajax通信（表示）
            $.ajax({
                type:'POST',
                url:'../js/top_ajax.php',
                data: {
                    // グループidを送信
                    group:group_id,
                    year:day
                },
                cache:false
            })
            .done(function(data){
                create_html(data);
            })
        }
        
        
    }else if(event.activeIndex == 2){

        let day;
        $('.swiper').remove();
        $('.wrap').append(
            '<div class="event_contena swiper">'+
                '<div class="swiper-wrapper">'+
                    '<div  class="swiper-slide"></div>'+
                    '<div  class="swiper-slide"></div>'+
                    '<div  class="swiper-slide"></div>'+
                '</div>'+
            '</div>'
        );
        var mySwiper = new Swiper(".swiper",{
            spaceBetween:10,
            slidesPerView:1,
            watchActiveIndex:true,
            initialSlide:1,
            touchRatio:0.3,
            centeredSlides:true,
            touchAngle: 20,
            on: {
                // 切り替わりのアニメーションが終了したとき
                slideChangeTransitionEnd: function(event) {
                    N_swiper(event);
                }
            }
        });
        if(month == 12){
            year = Number(year) + 1;
            month = 1;
            
            // headerの年月の更新
            $('#year').empty();
            $('#year').append(year+"年"+month+"月");

            day = year+'-01';
            // ajax通信
            $.ajax({
                type:'POST',
                url:'../js/top_ajax.php',
                data: {
                    // グループidを送信
                    group:group_id,
                    year:day
                },
                cache:false
            })
            .done(function(data){
                create_html(data);
            })
        }else{
            month = Number(month) + 1;

            // headerの年月の更新
            $('#year').empty();
            $('#year').append(year+"年"+month+"月");
            if(month != 12 && month != 11 && month != 10){
                let mon = '0'+month;
                day = year+'-'+mon;
            }else{
                day = year+'-'+ month;
            }
            // ajax通信
            if(month == 12){
                console.log(month);
                console.log(day);
                $.ajax({
                    type:'POST',
                    url:'../js/top_ajax.php',
                    data: {
                        // グループidを送信
                        group:group_id,
                        year2:day
                    },
                    cache:false
                })
                .done(function(data){
                    create_html(data);
                })
                .fail(function(data){
                    console.log('fail');
                });
            }else{
                $.ajax({
                    type:'POST',
                    url:'../js/top_ajax.php',
                    data: {
                        // グループidを送信
                        group:group_id,
                        year:day
                    },
                    cache:false
                })
                .done(function(data){
                    create_html(data);
                })
                .fail(function(data){
                    console.log('fail');
                });
            }
        }
    }

}

// イベント登録ボタンクリック時
$('.blue').on('touchend',function(){
    // グループがない場合
    if(!group_id){
        $('#non_group').empty();
        // TOP画面に表示
        $('#non_group').append('<p>グループを登録してください</p>');

        // ボタンの色落ち対策
        $('.blue').css('background-color','#669AE1');
    }else{
        // リンク
        let event_link = '../Controller/event_register.php';

        $.ajax({
            type:'POST',
            url:'../js/top_ajax.php',
            data: {
                // グループidを送信
                event_id:group_id
            },
            cache:false
        })
        .done(function(data){
            // イベント登録ページに遷移
            location.href= event_link;
        })
    }
    
});

// グループ名クリック時
$('#group_name').on('touchend',function(){
    console.log(group_id);
    $.ajax({
        type:'POST',
        url:'../js/top_ajax.php',
        data: {
            // グループidを送信
            g_name:group_id
        },
        cache:false
    })
    .done(function(data){
        window.location.href = '../Controller/group_detail.php';
    })
})

// html作成関数
function create_html(data){
    if(data['page1_date'].length != 0){
        let i,event_day,now_day,age,flg=0;
        for(i=0;i<data['page1_date'].length;i++){
            now_day =  data['date'].split('-');
            event_day = data['page1_date'][i]['birthday'].split('-');
            // 「月」の始まりが０かどうか
            if(event_day[1].slice(0,1) == 0){
                event_day[1] = event_day[1].slice(1);
            }

            // 「日」の始まりが０かどうか
            if(event_day[2].slice(0,1) == 0){
                event_day[2] = event_day[2].slice(1);
            }
            age = Number(now_day[0])-Number(event_day[0]);
            if(age < 0){
                flg++;
            }
            date_create_html(data,event_day,i,'.swiper-slide-prev','page1_date',age);
        }
    }else if(data['page1'].length == 0){
        $('.swiper-slide-prev').append("<p class='event_empty'>まだイベントが登録されていません</p>");
    }

    if(data['page1'].length != 0){
        let i;
        let event_day;
        for(i=0; i<data['page1'].length;i++){
            // 「月」の始まりが０かどうか
            event_day = data['page1'][i]['date'].split('-');
            if(event_day[1].slice(0,1) == 0){
                event_day[1] = event_day[1].slice(1);
            }

            // 「日」の始まりが０かどうか
            if(event_day[2].slice(0,1) == 0){
                event_day[2] = event_day[2].slice(1);
            }
            
            $('.swiper-slide-prev').append(
                    // イベントセクション
                    "<div class='event_section' id='"+data['page1'][i]['id']+"'>"+
                        "<div class='contena'>"+
                            // 日付側
                            "<div class='right'>"+
                                "<p class='day'>"+event_day[2]+"日</p>"+
                            "</div>"+

                            // イベント側 
                            "<div class='left'>"+
                                // イベント名
                                "<h2>"+data['page1'][i]['name']+"</h2>"+
                
                                "<div class='e_img_contena' id='img_"+data['page1'][i]['id']+"'></div>"+
                                // イベントに登録されたコメント
                                "<p>"+data['page1'][i]['comment']+"</p>"+
                            "</div>"+
                        "</div>"+
                    "</div>"
            );
            for(let j=0;j < Math.min(2,data['page1_ext'][i].length);j++){
                $('#img_'+data['page1'][i]['id']).append(
                    "<div class='e_img'><img src='../group/"+data['page1'][i]['group_id']+"/event_img/"+data['page1'][i]['id']+"/group"+data['page1'][i]['group_id']+"_"+data['page1_ext'][i][j]['id']+"."+data['page1_ext'][i][j]['extension']+"' alt=''></div>"
                )
            }                  
        }
    }

    if(data['page2_date'].length != 0){
        let i,event_day,now_day,age,flg=0;
        for(i=0;i<data['page2_date'].length;i++){
            event_day = data['page2_date'][i]['birthday'].split('-');
            now_day =  data['date'].split('-');
            // 「月」の始まりが０かどうか
            if(event_day[1].slice(0,1) == 0){
                event_day[1] = event_day[1].slice(1);
            }

            // 「日」の始まりが０かどうか
            if(event_day[2].slice(0,1) == 0){
                event_day[2] = event_day[2].slice(1);
            }
            age = Number(now_day[0])-Number(event_day[0]);
            if(age < 0){
                flg++;
            }
            date_create_html(data,event_day,i,'.swiper-slide-active','page2_date',age);
        }
    }else if(data['page2'].length == 0){
        $('.swiper-slide-active').append("<p class='event_empty'>まだイベントが登録されていません</p>");
    }

    if(data['page2'].length != 0){
        // イベントがあったとき
        let i;
        let event_day;
        for(i=0; i<data['page2'].length;i++){
            // 「月」の始まりが０かどうか
            event_day = data['page2'][i]['date'].split('-');
            if(event_day[1].slice(0,1) == 0){
                event_day[1] = event_day[1].slice(1);
            }

            // 「日」の始まりが０かどうか
            if(event_day[2].slice(0,1) == 0){
                event_day[2] = event_day[2].slice(1);
            }
            var id = [data['page2'][i]['id'],data['page2'][i]['group_id'],data['page2'][i]['date']];
            $('.swiper-slide-active').append(
                    // イベントセクション
                    "<div class='event_section fadeUpTrigger'>"+
                        "<a href='./group.php?event_id="+id+"'> </a>"+
                        "<div class='contena'>"+
                            // 日付側
                            "<div class='right'>"+
                                "<p class='day'>"+event_day[2]+"日</p>"+
                            "</div>"+

                            // イベント側 
                            "<div class='left'>"+
                                // イベント名
                                "<h2>"+data['page2'][i]['name']+"</h2>"+
                
                                "<div class='e_img_contena' id='img_"+data['page2'][i]['id']+"'></div>"+
                                // イベントに登録されたコメント
                                "<p>"+data['page2'][i]['comment']+"</p>"+
                            "</div>"+
                        "</div>"+
                    "</div>"
            );
            for(let j=0;j < Math.min(2,data['page2_ext'][i].length);j++){
                $('#img_'+data['page2'][i]['id']).append(
                    "<div class='e_img'><img src='../group/"+data['page2'][i]['group_id']+"/event_img/"+data['page2'][i]['id']+"/group"+data['page2'][i]['group_id']+"_"+data['page2_ext'][i][j]['id']+"."+data['page2_ext'][i][j]['extension']+"' alt=''></div>"
                )
            }                  
        }
    }

    if(data['page3_date'].length != 0){
        let i,event_day,now_day,age,flg=0;
        for(i=0;i<data['page3_date'].length;i++){
            event_day = data['page3_date'][i]['birthday'].split('-');
            now_day =  data['date'].split('-');
            // 「月」の始まりが０かどうか
            if(event_day[1].slice(0,1) == 0){
                event_day[1] = event_day[1].slice(1);
            }

            // 「日」の始まりが０かどうか
            if(event_day[2].slice(0,1) == 0){
                event_day[2] = event_day[2].slice(1);
            }
            age = Number(now_day[0])-Number(event_day[0]);
            if(age < 0){
                flg++;
            }
            date_create_html(data,event_day,i,'.swiper-slide-next','page3_date',age);
        }
    }else if(data['page3'].length == 0){
        $('.swiper-slide-next').append("<p class='event_empty'>まだイベントが登録されていません</p>");  
    }

    if(data['page3'].length != 0){
        let i;
        let event_day;
        for(i=0; i<data['page3'].length;i++){
            // 「月」の始まりが０かどうか
            event_day = data['page3'][i]['date'].split('-');
            if(event_day[1].slice(0,1) == 0){
                event_day[1] = event_day[1].slice(1);
            }

            // 「日」の始まりが０かどうか
            if(event_day[2].slice(0,1) == 0){
                event_day[2] = event_day[2].slice(1);
            }
            
            $('.swiper-slide-next').append(
                    // イベントセクション
                    "<div class='event_section' id='"+data['page3'][i]['id']+"'>"+
                        "<a href='./'></a>"+
                        "<div class='contena'>"+
                            // 日付側
                            "<div class='right'>"+
                                "<p class='day'>"+event_day[2]+"日</p>"+
                            "</div>"+

                            // イベント側 
                            "<div class='left'>"+
                                // イベント名
                                "<h2>"+data['page3'][i]['name']+"</h2>"+
                
                                "<div class='e_img_contena' id='img_"+data['page3'][i]['id']+"'></div>"+
                                // イベントに登録されたコメント
                                "<p>"+data['page3'][i]['comment']+"</p>"+
                            "</div>"+
                        "</div>"+
                    "</div>"
            );
            for(let j=0;j < Math.min(2,data['page3_ext'][i].length);j++){
                $('#img_'+data['page3'][i]['id']).append(
                    "<div class='e_img'><img src='../group/"+data['page3'][i]['group_id']+"/event_img/"+data['page3'][i]['id']+"/group"+data['page3'][i]['group_id']+"_"+data['page3_ext'][i][j]['id']+"."+data['page3_ext'][i][j]['extension']+"' alt=''></div>"
                )
            }                  
        }
    }
}


// 誕生日のhtml
function date_create_html(data,event_day,i,page,data_name,age){
    if(age == 0 || age > 0){
        $(page).append(
            // イベントセクション
            "<div class='event_section birthday_gradate fadeUpTriggers month"+event_day[1]+"' id='"+data[data_name][i]['id']+"'>"+
                "<div class='contena'>"+
                    // 日付側
                    "<div class='right'>"+
                        "<p class='day'>"+event_day[2]+"日</p>"+
                    "</div>"+
    
                    // イベント側 
                    "<div class='left'>"+
                        // 内容
                        "<h3>"+data[data_name][i]['name']+"さん<br>"+age+"歳の誕生日</h3>"+
                        '<img src="../img/material/birthday_cake.png"></img>'+
                    "</div>"+
                "</div>"+
            "</div>"
        );
    }else if(data[data_name].length == 0){
        $(page).append("<p class='event_empty'>まだイベントが登録されていません</p>");
    }
}
// 1.関数の定義
function setHeight() {
    let vh = window.innerHeight * 0.01;
    document.documentElement.style.setProperty('--vh', `${vh}px`);
  }
  
  // 2.初期化
  setHeight();
  
  // 3.ブラウザのサイズが変更された時・画面の向きを変えた時に再計算する
  window.addEventListener('resize', setHeight);