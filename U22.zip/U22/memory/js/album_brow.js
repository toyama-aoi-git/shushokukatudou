$(function () {
    // グループIDの取得
    let group_id = js_php_g;
    // アルバムIDの取得
    let album_id = js_php_a;

    // データの取得と表示
    $.ajax({
        type: "POST",
        url: "../js/load_js_1.php",
        dataType: "json",
        data: {
            album_load: album_id,
            group_load: group_id
        },
        async: false,
        cache: false
    })
        .done(function (json) {
            var all_pages_num = Object.keys(json).length;

            // メディアとフリップブックの要素を追加
            $("<div id='media'></div>").appendTo("body");
            $("<div id='flipbook'></div>").appendTo("#media");

            // ページごとに処理
            for (let i = 0; i < all_pages_num; i++) {
                var hll_div = document.createElement('div');
                hll_div.className = "hll";
                var gradient_direction = i % 2 == 1 ? "to right" : "to left";
                var css = "background: linear-gradient(" + gradient_direction + ", " + json[i]['background_color'] + " 90%, gray);";
                hll_div.style.cssText = css;
                $("#flipbook").append(hll_div);
            }

            var hlls = $('.hll');
            for (let i = 0; i < all_pages_num; i++) {
                var pages_num = Object.keys(json[i]).length;
                for (let t = 0; t < pages_num - 1; t++) {
                    var media = document.createElement('div');
                    media.style.cssText = "top:" + json[i][t]["top"] + ";" + "left: " + json[i][t]["left"] + ";";
                    media.className = json[i][t]["className"];
                    media.innerHTML = json[i][t]["html"];
                    hlls[i].append(media);
                }
            }
        })
        .fail(function (error) {
            console.log("通信失敗");
            console.log("失敗", error.status, error.statusText);
        })
        .always(function () {
            console.log("処理終了");
        });

    // 本の縦幅 = スマホの横幅
    let book_height = window.parent.screen.width;

    // 比率
    let per = book_height / 30;

    // 本の横幅
    let book_width = per * 40;

    // サイズ
    $('#flipbook').turn({
        width: 400,
        height: 300,
        autoCenter: true
    });
});
