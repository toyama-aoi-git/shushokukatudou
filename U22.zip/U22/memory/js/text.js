var toFullWidth = function (value) {
    if (typeof value !== 'string') return value;

    return String(value).replace(/[!-~]/g, function (all) {
        return String.fromCharCode(all.charCodeAt(0) + 0xFEE0);
    });
};

$(document).on("touchend", ".img_plus", function () {
    $(".none").removeClass("none");
    $(this).addClass("none");
    $(".img_check").removeClass("none");
    $(".add_text").addClass("none");
    document.getElementsByClassName("add_tx")[0].onsubmit = function () { return false };

});
$(document).on("touchend", ".img_check", function () {
    const text = document.form1.input1.value;
    $(this).addClass("none");
    $(".add_input").addClass("none");
    $(".img_plus").removeClass("none");
    $(".add_text").removeClass("none");
    document.getElementsByClassName("add_text")[0].textContent = text;

    const str = text;

    if (/^[^\x01-\x7E\uFF61-\uFF9F]+$/.test(str) == true) {
        // 全角文字の時の処理を記述
        console.log('全角');
        var el = $(".add_text").css("font-size");
        const regex = /[^0-9]/g;
        const result = el.replace(regex, "");
        var number = parseInt(result);
        var plus = Number(number) * Number(text.length);
    } else {
        // 半角文字の時の処理を記述
        console.log('半角');
        var el = $(".add_text").css("font-size");
        const regex = /[^0-9]/g;
        const result = el.replace(regex, "");
        var number = parseInt(result);
        document.getElementsByClassName("add_text")[0].textContent = toFullWidth(text);
        var plus = Number(number) * Number(text.length);
    }

    $(".img_plus").css({ "left": plus + "px" });
});