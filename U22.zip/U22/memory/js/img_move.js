// スクロールを禁止する関数
function handleTouchMove(event) {
    event.preventDefault();
}

// タッチ開始時の処理
$(document).on("touchstart", ".media", function (e) {
    // スクロール禁止を設定
    document.addEventListener('touchmove', handleTouchMove, { passive: false });

    // 画像のクラスを操作して現在選択中の状態にする
    $('.now').removeClass('now');
    $(this).addClass('now');

    // タッチした要素を最前面に表示する
    $(this).siblings().css('z-index', 'auto');
    $(this).css('z-index', '1');

    // タッチ位置と要素の位置の差を計算
    var mouse = {
        x: e.changedTouches[0].pageX,
        y: e.changedTouches[0].pageY
    };
    var div_position = $(this).offset();
    offset = {
        x: 0,
        y: 0
    };
    offset.x = mouse.x - div_position.left;
    offset.y = mouse.y - div_position.top;

    // 要素の削除領域を設定
    delete_area = {
        top: 0 - $(this).children().height() * 0.8,
        left: 0 - $(this).children().width() * 0.8,
        right: 0 + 300,
        bottom: 0 + 200
    };
});

// タッチ移動時の処理
$(document).on("touchmove", ".media", function (e) {
    // タッチ位置の座標を取得
    var mouse = {
        x: e.changedTouches[0].pageX,
        y: e.changedTouches[0].pageY
    };

    // タッチ位置から差分を引いて要素を移動させる
    var position = {
        x: mouse.x - offset.x,
        y: mouse.y - offset.y
    };
    $(this).offset({
        top: position.y,
        left: position.x
    });

    // 要素の削除領域と重なった場合は要素を削除
    var img_scale = {
        top: Number($(this).css('top').split("px")[0]) * 0.8,
        left: Number($(this).css('left').split("px")[0]) * 0.8,
        right: Number($(this).css('top').split("px")[0]),
        bottom: Number($(this).css('left').split("px")[0])
    };
    if (delete_area.top > img_scale.top || delete_area.left > img_scale.left || delete_area.right < img_scale.right || delete_area.bottom < img_scale.bottom) {
        $(this).remove();
    }
});

// タッチ終了時の処理
$(document).on("touchend", ".media", function () {
    // スクロール禁止を解除
    document.removeEventListener('touchmove', handleTouchMove, { passive: false });
});
