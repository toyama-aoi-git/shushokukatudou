$(".add-group").addClass("none");

$(document).on("click", ".add-media-btn", function () {
    var img_stack = $(".img_stack");
    var add_img = [];

    for (var i = 0; i < img_stack.length; i++) {
        if ($(img_stack[i]).data("img_situation") == 1) {
            add_img = i;
            $(this).parent().append(`<div class="media absolute" style="z-index: 1; top: 25%; left: 25%;"><img class="img" src="${$(img_stack[i]).attr('src')}" alt="" width="70px" height="auto" style="transform : rotate(0deg)"></div>`);
        }
    }

    $(".img_stack").data("img_situation", 0);
    $(".img_stack").css("border", "");
});

// アルバム背景色変更ボタン
$(document).on("click", ".add-color-btn", function () {
    var aa = $(this).parent().attr('class');
    var bb = aa.includes('even');

    if (bb) {
        $(this).parent().css("background", `linear-gradient(to right, ${$(".color").val()} 90%, gray)`);
    } else {
        $(this).parent().css("background", `linear-gradient(to left, ${$(".color").val()} 90%, gray)`);
    }
});

// 編集可能モード切り替えON
$(document).on("click", "#disable-btn", function () {
    console.log("編集可能モードON");
    $(".absolute").addClass("media");
    $(".add-group").removeClass("none");
    $("#flipbook").turn("disable", true);
    var hlls = document.getElementsByClassName('hll');
    var hlls_style = window.getComputedStyle(hlls[0]);
    var background_color = hlls_style.getPropertyValue("background").split(")")[1] + ")";
    var background_color = background_color.split("t, ")[1];
    console.log(background_color);
});

// 編集可能モード切り替えOFF
$(document).on("click", "#enables-btn", function () {
    console.log("編集可能モードOFF");
    $(".absolute").removeClass("media");
    $(".add-group").addClass("none");
    $("#flipbook").turn("disable", false);
});
