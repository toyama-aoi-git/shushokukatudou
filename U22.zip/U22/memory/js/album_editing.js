$(function () {
    // グループIDの取得
    let group_id = js_php_g;
    console.log(group_id);
    // アルバムIDの取得
    let album_id = js_php_a;

    console.log(album_id);
    $.ajax({
        type: "POST",
        url: "../js/load_js_1.php",
        dataType: "json",
        data: {
            // アルバムid,グループidを送信
            album_load: album_id,
            group_load: group_id
        },
        async: false,
        cache: false
    })
        .done(function (json) {
            var all_pages_num = Object.keys(json).length;

            var media_div = $("<div>").attr("id", "media");
            $("#contena").append(media_div);

            var flipbook_div = $("<div>").attr("id", "flipbook");
            $("#media").append(flipbook_div);

            for (let i = 0; i < all_pages_num; i++) {
                var hll_div = $("<div>").addClass("hll");
    
                if (i % 2 == 1) {
                    var css = "background: linear-gradient(to right ," + json[i]['background_color'] + " 90%, gray);";
                }
                else {
                    var css = "background: linear-gradient(to left ," + json[i]['background_color'] + " 90%, gray);";
                }
    
                hll_div.attr("style", css);
                $("#flipbook").append(hll_div);
            };

            var hlls = $('.hll');
            console.log(hlls);
            for (let i = 0; i < all_pages_num; i++) {
                if (i == 0) {
                    // 色
                    var ado = document.createElement('button');
                    ado.setAttribute('type', 'button');
                    ado.setAttribute('id', 'color');
                    ado.classList.add('add-group');
                    ado.classList.add('add-color-btn');
                    ado.classList.add('button');
                    ado.classList.add('none');
                    ado.style.zIndex = 'auto';

                    var img = document.createElement('img');
                    img.setAttribute('src', '../img/material/paint.png');
                    img.style.width = '20px';

                    ado.append(img);
                    hlls[i].append(ado);
                } else if (i + 1 != all_pages_num) {
                    // 色
                    var ado = document.createElement('button');
                    ado.setAttribute('type', 'button');
                    ado.setAttribute('id', 'color');
                    ado.classList.add('add-group');
                    ado.classList.add('add-color-btn');
                    ado.classList.add('button');
                    ado.classList.add('none');
                    ado.style.zIndex = 'auto';

                    var img = document.createElement('img');
                    img.setAttribute('src', '../img/material/paint.png');
                    img.style.width = '20px';

                    ado.append(img);
                    hlls[i].append(ado);

                    // 追加
                    var add = document.createElement('button');
                    add.setAttribute('type', 'button');
                    add.setAttribute('id', 'photo');
                    add.classList.add('add-group');
                    add.classList.add('add-media-btn');
                    add.classList.add('button');
                    add.classList.add('none');

                    var img = document.createElement('img');
                    img.setAttribute('src', '../img/material/img2.png');
                    img.style.width = '20px';

                    add.append(img);
                    hlls[i].append(add);
                }

                var pages_num = Object.keys(json[i]).length;
                for (let t = 0; t < pages_num - 1; t++) {
                    var media = document.createElement('div');
                    media.style.cssText = "top:" + json[i][t]["top"] + ";" + "left: " + json[i][t]["left"] + ";";
                    media.className = json[i][t]["className"];
                    media.innerHTML = json[i][t]["html"];
                    hlls[i].append(media);
                }
            }

            $("#flipbook").turn({
                width: 400,
                height: 300,
                autoCenter: true
            });
        })//失敗時
        .fail(function (error) {
            console.log("通信失敗");
            console.log("失敗", error.status, error.statusText);

        })//どちらでも
        .always(function () {
            console.log("処理終了");
        })
});

// 追加画像選択：枠表示＆flag管理
$(document).on("click", ".img_stack", function () {

    if ($(this).data("img_situation") == 1) {
        $(this).data("img_situation", 0);
        $(this).css({ "border": "" });
    }
    else {
        $(this).data("img_situation", 1);
        $(this).css({ "border": "10px solid #ff9633" });
    }
    console.log($(this).data("img_situation"));
});


// 編集完了ボタン
$(document).on("click", "#album_editing_end", function () {
    let editing = 1;
    let events_id = js_php;
    var divsJsons = {};
    var hlls = document.getElementsByClassName('hll');
    for (var i = 0; i < hlls.length; i++) {
        var divsJson = {};
        var hlls_style = window.getComputedStyle(hlls[i]);
        var background_color = hlls_style.getPropertyValue("background").split(")")[1] + ")";
        var background_color = background_color.split("t, ")[1];
        divsJson["background_color"] = background_color;
        if (i == 0) {

            for (var t = 0; t < hlls[i].getElementsByClassName("album_top_media").length; t++) {
                var document_0 = hlls[i].getElementsByClassName("album_top_media")[t];
                var mediaDiv = {
                    top: document_0.style.top,
                    left: document_0.style.left,
                    className: document_0.className,
                    html: document_0.innerHTML
                };
                divsJson[t] = mediaDiv;
            };
        } else {

            for (var t = 0; t < hlls[i].getElementsByClassName("absolute").length; t++) {
                var document_0 = hlls[i].getElementsByClassName("absolute")[t];
                var mediaDiv = {
                    top: document_0.style.top,
                    left: document_0.style.left,
                    className: document_0.className,
                    html: document_0.innerHTML
                };
                divsJson[t] = mediaDiv;
            }

        }
        divsJsons[i] = divsJson;
    }
    var outputString = JSON.stringify(divsJsons);
    $.ajax({
        type: 'post',
        dataType: 'text',
        data: {
            'data': outputString,
            events_id: events_id,
            flg: editing
        },
        cache: false,
        url: "../js/save_js_1.php"
    }).done(function (data) {
        console.log(data);
    })//失敗時
        .fail(function (error) {
            console.log("通信失敗");
            console.log("失敗", error.status, error.statusText);
        })//どちらでも
        .always(function () {
            console.log("処理終了");
        })
});

// toggle
$("#stamp_in").hide();
$('#toggle_switch').click(function () {
    $("#photo_in").toggle();
    $("#stamp_in").toggle();
});    