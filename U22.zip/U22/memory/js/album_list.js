$(function () {
    let group_id = js_php;
    let height = window.innerHeight;

    // アルバムラインを作成する関数
    const createAlbumLine = (start, end) => {
        for (let i = start; i <= end; i += 2) {
            $('#contena').append(`<div class='album-line before' id='line${i}'></div>`);
        }
    };

    // 画面の高さに応じてアルバムラインを作成
    if (height > 700) {
        createAlbumLine(0, 6);
    } else {
        createAlbumLine(0, 4);
    }

    // アルバムリストを取得して表示する
    $.ajax({
        type: 'POST',
        url: '../js/album_list_ajax.php',
        data: {
            load: group_id
        },
        async: false,
        cache: false
    }).done(function (data) {
        if (data.length != 0) {
            for (let h = 0; h < data.length; h++) {
                let album_id = data[h]['id'];
                // アルバムの情報を取得して表示する
                $.ajax({
                    type: "POST",
                    url: "../js/load_js_1.php",
                    dataType: "json",
                    data: {
                        album_load: album_id,
                        group_load: group_id
                    },
                    async: false,
                    cache: false
                }).done(function (json) {
                    if (h % 2 == 0) {
                        // 偶数番目のアルバムは新しいアルバムラインに追加
                        if (height > 700 && h >= 8) {
                            $('#contena').append("<div class='album-line' id='line" + h + "'></div>");
                        } else if (height <= 700 && h >= 6) {
                            $('#contena').append("<div class='album-line' id='line" + h + "'></div>");
                        }
                        $("#line" + h).removeClass('before');

                        var album_div = document.createElement('div');
                        album_div.id = "album" + album_id;
                        $(album_div).addClass("book");
                        $("#line" + h).append(album_div);

                        var media_div = document.createElement('div');
                        media_div.id = "flipbook" + album_id;
                        $(media_div).addClass("flipbook");
                        $(album_div).append(media_div);

                        var hll_div = document.createElement('div');
                        hll_div.className = "hll";
                        hll_div.style.cssText = "background-color: " + json[0]["background_color"] + ";";
                        $("#flipbook" + album_id).append(hll_div);

                        $(hll_div).append("<a class='book_a' href='./album_list.php?id=" + album_id + "'></a>");

                        var hlls = $("#flipbook" + album_id).find('.hll');
                        var pages_num = Object.keys(json[0]).length - 1;
                        for (let t = 0; t < pages_num; t++) {
                            var media = document.createElement('div');
                            media.className = json[0][t]["className"];
                            media.className = "absolute";
                            media.innerHTML = json[0][t]["html"];
                            hlls[0].append(media);
                        }
                    } else {
                        // 奇数番目のアルバムは直前のアルバムラインに追加
                        var album_div = document.createElement('div');
                        album_div.id = "album" + album_id;
                        $(album_div).addClass("book");
                        $("#line" + (h - 1)).append(album_div);

                        var media_div = document.createElement('div');
                        media_div.id = "flipbook" + album_id;
                        $(media_div).addClass("flipbook");
                        $(album_div).append(media_div);

                        var hll_div = document.createElement('div');
                        hll_div.className = "hll";
                        hll_div.style.cssText = "background-color: " + json[0]["background_color"] + ";";
                        $("#flipbook" + album_id).append(hll_div);

                        $(hll_div).append("<a class='book_a' href='./album_list.php?id=" + album_id + "'></a>");

                        var hlls = $("#flipbook" + album_id).find('.hll');
                        var pages_num = Object.keys(json[0]).length - 1;
                        for (let t = 0; t < pages_num; t++) {
                            var media = document.createElement('div');
                            media.className = json[0][t]["className"];
                            media.innerHTML = json[0][t]["html"];
                            hlls[0].append(media);
                        }
                    }
                })
            }
        }
    })

    // アルバム本棚のタイトルスタイル
    $(".add_text").css({ 'lineHeight': '112px', 'width': '84px', 'whiteSpace': 'noWrap', 'overflow': 'hidden', 'textOverflow': 'ellipsis', 'textAlign': 'center' });
});
