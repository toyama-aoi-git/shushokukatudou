// 外部読み込み
// import('./filters.js').then(filter => {
//     var filters = new filter.myutil();
// });
// インスタンス化
// import filter from './filters.js';


/////////////////////////////////////////////////////////////////////////////////////////////////////////////
// テンプレートフィルター
$("a").on('click', function () {
    // 初期化
    function_list["normal_btn"]();
    // フィルター適用
    function_list[$(this).data("preset")]();

    // let canvas = $("#canvas");
    // let url = canvas.toDataURL();
    // console.log(url);
});

// 効果；調節スライダー
$('#Filters').on('change', '.FilterSetting input', function () {
    var filter, value;
    // 効果名取得
    filter = $(this).data('filter');
    // 効果パラメータ取得
    value = $(this).val();

    console.log($("#brightness").val());
    // 効果パラメータ描画
    $(this).find('~ .FilterValue').html(value);

    // 効果パラメータ保存
    var brightness = parseInt($("#brightness").val());
    var contrast = parseInt($("#contrast").val());
    var saturation = parseInt($("#saturation").val());
    var vibrance = parseInt($("#vibrance").val());
    var exposure = parseInt($("#exposure").val());
    var hue = parseInt($("#hue").val());
    var sepia = parseInt($("#sepia").val());
    var gamma = parseInt($("#gamma").val());
    var sepia = parseInt($("#sepia").val());
    var noise = parseInt($("#noise").val());
    var clip = parseInt($("#clip").val());
    var sharpen = parseInt($("#sharpen").val());
    var stackBlur = parseInt($("#stackBlur").val());


    Caman("#sourceCanvas", img, function () {
        // 効果初期化
        this.revert();

        this.brightness(brightness).contrast(contrast).saturation(saturation).vibrance(vibrance).exposure(exposure).hue(hue).sepia(sepia).gamma(gamma).sepia(sepia).noise(noise).clip(clip).sharpen(sharpen).stackBlur(stackBlur).render();
        // this.brightness(brightness).contrast(contrast).saturation(saturation).vibrance(vibrance).exposure(exposure).hue(hue).sepia(sepia).gamma(gamma).sepia(sepia).noise(noise).clip(clip).sharpen(sharpen).stackBlur(stackBlur).render();
        // this.gamma(gamma).render();
    });
});

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// 以下コピペ。動いてるからﾖｼ！
var img = new Image();
var canvas = document.getElementById("sourceCanvas");
var ctx = canvas.getContext("2d");
var fileName = "";

$(document).ready(function () {
    $("#download-btn").on("click", function (e) {
        var fileExtension = fileName.slice(-4);
        if (fileExtension == ".jpg" || fileExtension == ".png") {
            var actualName = fileName.substring(0, fileName.length - 4);
        }
        download(canvas, actualName + "-edited.jpg");
    });

    $("#upload-file").on("change", function () {
        var file = document.querySelector("#upload-file").files[0];
        var reader = new FileReader();

        if (file) {
            fileName = file.name;
            reader.readAsDataURL(file);
        }

        reader.addEventListener(
            "load",
            function () {
                img = new Image();
                img.src = reader.result;
                img.onload = function () {
                    // canvas.width = img.width/2;って書くとサイズが半分になる
                    canvas.width = img.width;
                    canvas.height = img.height;
                    ctx.drawImage(img, 0, 0, img.width, img.height);
                    $("#sourceCanvas").removeAttr("data-caman-id");
                };
            },
            false
        );
    });
});

function download(canvas, filename) {
    var e;
    var lnk = document.createElement("a");

    lnk.download = filename;

    lnk.href = canvas.toDataURL("image/jpeg", 0.8);

    if (document.createEvent) {
        e = document.createEvent("MouseEvents");
        e.initMouseEvent(
            "click",
            true,
            true,
            window,
            0,
            0,
            0,
            0,
            0,
            false,
            false,
            false,
            false,
            0,
            null
        );
        lnk.dispatchEvent(e);
    } else if (lnk.fireEvent) {
        lnk.fireEvent("onclick");
    }
}