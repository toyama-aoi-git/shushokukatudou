$('#birthday').focus(function (e) { 
    console.log('ふぉーかす');
    $(this).attr('type', 'date');
    $('#birthday').trigger('click');
});


$('#birthday').blur(function (e) { 
    console.log('ふぉーかすからはずれる');
    $(this).attr('type', 'text');
});


