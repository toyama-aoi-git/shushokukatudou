<?php

require_once '../../config.php';
require_once '../function/function.php';

header("Content-Type: application/json; charset=UTF-8");
$search = h($_GET['code']);

$result = false;

$sql = "SELECT g.id , g.name , g.icon , g.invitation
        FROM `group` g
        WHERE g.invitation = '". $search ."'";

$link = mysqli_connect(HOST , USER_ID , PASSWORD , DB_NAME);
mysqli_set_charset($link , 'utf8'); 

$result = sql_search($link , $sql);


if(!is_null($result)){
    $search_result = $result[0];
    echo json_encode($search_result);
    exit;
}
else{
    exit;
}

?>