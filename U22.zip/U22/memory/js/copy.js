console.log('OK');
const code = $('#code').text();
console.log(code);


// $('#codeButton').click(function (e) { 
//     console.log('くりっく');
//     $('#code').css('color', 'red');
//     navigator.clipboard.writeText(code);
//     $('#code').text('コピー完了！');
//     // code.innerHTML = 'コピー完了！'
//     setTimeout(() => $('#code').text(code), 1000);
// });


$('#codeButton').on('touchstart', function(){
    console.log('くりっく');
    // $('#code').css('color', 'red');
    navigator.clipboard.writeText(code);
    // $('#code').select();
    // document.execCommand("copy");
    $('#code').text('コピー完了！');
    // code.innerHTML = 'コピー完了！'
    setTimeout(() => $('#code').text(code), 1000);
});

