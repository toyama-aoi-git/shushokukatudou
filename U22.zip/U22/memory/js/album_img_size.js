$(function() {
    $(document).on('input', '#size', function() {
        if($('.now') != undefined){
            $('.now').children('img').css({"width" : $(this)[0].value+"px"});
        }
    });

    $(document).on('input', '#reg', function() {
        if($('.now') != undefined){
            $('.now').children('img').css({"transform" : "rotate( " + $(this)[0].value + "deg )"});
        }
    });
});