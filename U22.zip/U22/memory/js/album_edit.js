// アルバム作成
$(document).on("click", ".add_id", function () {
    var img_stack = $(".border_box");
    var img_stack2 = $(".img_stack");

    var add_id = [];
    var err;
    for (var i = 0; i < img_stack.length; i++) {
        if ($(img_stack[i]).data("img_situation") == 1) {
            add_id.push($(img_stack2[i]).attr("id"));
        }
    }

    $('#title_err').empty();

    let title = $('input[name="album_title"]').val();
    title = escapeSelectorString(title);

    if (title == '') {
        $('#title_err').append('アルバムタイトルを入力してください');
        err = 1;
    }

    $('#error').empty();
    if (add_id.length == 0) {
        $('#error').append('イベントを選択してください');
        err = 1;
    }

    // エラーがなかった時
    if (err != 1) {
        $.ajax({
            type: 'POST',
            url: '../js/box_border.php',
            data: {
                load: title
            },
            async: false,
            cache: false
        })
        .done(function (data) {
            var page = $("#page").val();
            console.log(add_id.toString());
            window.location = "./album_editor.php?id=" + add_id.toString() + "&page=" + page;
            exit();
        });
    } else {
        window.scroll({ top: 0, behavior: 'smooth' });
    }
});

// 追加画像選択：枠表示＆flag管理
$(document).on("click", ".border_box", function () {
    var imgSituation = $(this).data("img_situation");
    
    if (imgSituation == 1) {
        $(this).data("img_situation", 0);
        $(this).css({ "border": "" });
    } else {
        $(this).data("img_situation", 1);
        $(this).css({ "border": "10px solid #ff9633" });
    }

    console.log($(this).data("img_situation"));
});

// エスケープ処理
function escapeSelectorString(val) {
    return val.replace(/[ !"#$%&'()*+,.\/:;<=>?@\[\\\]^`{|}~]/g, "\\$&");
}

$("select").on("click", function () {
    $(this).parent(".custom-select").toggleClass("open");
});

$(document).click(function (e) {
    var container = $(".custom-select");

    if (container.has(e.target).length === 0) {
        container.removeClass("open");
    }
});

$("select").on("change", function () {
    var selection = $(this).find("option:selected").text();
    var labelFor = $(this).attr("id");
    var label = $("[for='" + labelFor + "']");

    label.find(".selection-choice").html(selection);
});
