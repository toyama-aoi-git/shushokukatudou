//イベントチェンジ用
const photoClick = document.getElementsByClassName('imgOpen');
const modal = document.getElementById('easyModal');
const buttonClose = document.getElementsByClassName('modalClose');

console.log();

// ボタンがクリックされた時
$(photoClick).click(function(e){ 
    // console.log('おーぷん');
    let src = $(this).attr('src');
    // console.log(src);
    $('.imgSrc').attr('src', src);
    //モーダルを表示する
    modal.style.display = 'block';
});


// バツ印がクリックされた時
$(buttonClose).click(function(e){ 
    // console.log('くろーず');
    modal.style.display = 'none';
});


// モーダルコンテンツ以外がクリックされた時
addEventListener('click', outsideClose);
    function outsideClose(e) {
    if (e.target == modal) {
        modal.style.display = 'none';
    }
}

