// 追加画像選択：枠表示＆flag管理
$(document).on("click", ".img_stack", function () {

    if ($(this).data("img_situation") == 1) {
        $(this).data("img_situation", 0);
        $(this).css({ "border": "" });
    }
    else {
        $(this).data("img_situation", 1);
        $(this).css({ "border": "10px solid #ff9633" });
        $(this).css({ "border-radius": "3%" });
    }
    console.log($(this).data("img_situation"));
});


// 作成完了ボタン
$(document).on("click", "#album_edit_end", function () {
    // アルバム初期設定画面で選んだイベントID　例：1,2
    let events_id = js_php;

    var divsJsons = {};
    var page = $('.page');
    var hlls = document.getElementsByClassName('hll');
    console.log(hlls);
    console.log(page);

    for (var i = 0; i < hlls.length; i++) {

        var divsJson = {};
        var hlls_style = window.getComputedStyle(hlls[i]);
        var background_color = hlls_style.getPropertyValue("background").split(")")[1] + ")";
        var background_color = background_color.split("t, ")[1];

        divsJson["background_color"] = background_color;
        if (i == 0) {

            for (var t = 0; t < hlls[i].getElementsByClassName("album_top_media").length; t++) {
                var document_0 = hlls[i].getElementsByClassName("album_top_media")[t];
                var mediaDiv = {
                    top: document_0.style.top,
                    left: document_0.style.left,
                    className: document_0.className,
                    html: document_0.innerHTML
                };
                divsJson[t] = mediaDiv;
            };
        } else {
            for (var t = 0; t < hlls[i].getElementsByClassName("absolute").length; t++) {
                var document_0 = hlls[i].getElementsByClassName("absolute")[t];
                var mediaDiv = {
                    top: document_0.style.top,
                    left: document_0.style.left,
                    className: document_0.className,
                    html: document_0.innerHTML
                };
                divsJson[t] = mediaDiv;
            }
        }

        divsJsons[i] = divsJson;
    }
    var outputString = JSON.stringify(divsJsons);
    $.ajax({
        type: 'post',
        dataType: 'text',
        data: {
            'data': outputString,
            events_id: events_id
        },
        cache: false,
        url: "../js/save_js_1.php"
    }).done(function (data) {
        console.log(data);
    })//失敗時
        .fail(function (error) {
            console.log("通信失敗");
            console.log("失敗", error.status, error.statusText);
        })//どちらでも
        .always(function () {
            console.log("処理終了");
        })
});

//toggle
$("#stamp_in").hide();
$('#toggle_switch').click(function () {
    $("#photo_in").toggle();
    $("#stamp_in").toggle();
});    