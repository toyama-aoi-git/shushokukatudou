$(function(){
    let name_val='',pass_val='',bir_val='';
    name_err='お名前が入力されていません',
    pass_err='パスワードが入力されていません',
    pass_err2='パスワードは16文字以内にしてください';

    // button押したとき
    $("#modalOpen").click(function(){
        // エラーメッセージを空に
        $('#err-msg-name').empty();
        $('#err-msg-pass').empty();

        // 名前　入力値チェック
        if(name_val == ''){
            $('#err-msg-name').append(name_err);
        }

        // パスワード　入力値チェック＋16文字いないかどうか
        if(pass_val == ''){
            $('#err-msg-pass').append(pass_err);
        }else if(pass_val.length > 16){
            $('#err-msg-pass').append(pass_err2);
        }

        // エラー文がなかった場合
        if($('#err-msg-name').text() == '' && $('#err-msg-pass').text() == ''){
            //　エスケープ処理
            name_val = escapeSelectorString(name_val);
            pass_val = escapeSelectorString(pass_val);

            // 重複チェック
            $.ajax({
                type:'POST',
                url:'./register.php',
                data: {
                    name_b:name_val,
                    pass_b:pass_val,
                },
                cache:false
            })
            .done(function(data){
                // 重複エラー文を空に
                $('#err-msg-dup').empty();

                // 重複がなかった場合
                if(data == ''){
                    $('#name_row td:last').empty();
                    $('#password_row td:last').empty();
                    $('#birthday_row td:last').empty();
        
                    // モーダル
                    // opne
                    $('#easyModal').css('display','block');
        
                    $('#name_row td:last').append(name_val);
                    $('#password_row td:last').append(pass_val);
                    if(bir_val == ''){
                        $('#birthday_row td:last').append('未登録');
                    }else{
                        $('#birthday_row td:last').append(bir_val);
                    }
        
                    // close ボタン
                    $('.modalClose').click(function(){
                        $('#easyModal').css('display','none');
                    });
        
                    // close 範囲外
                    $(document).click(function(e){
                        if (e.target == document.getElementById('easyModal')) {
                            $('#easyModal').css('display','none');
                        }
                    });
        
                    // 会員登録ボタン 登録処理
                    $('button[name="start"]').click(function(){
                        $.ajax({
                            type:'POST',
                            url:'./register.php',
                            data: {
                                name:name_val,
                                pass:pass_val,
                                bir:bir_val,
                            },
                            cache:false
                        })
                        .done(function(data){
                            // 画面遷移
                            window.location.href = "../Controller/group_list.php";
                            exit();
                        })
                        .fail(function(data){
                            console.log(data);
                        })
                    });
                }else{
                    $('#err-msg-dup').append('入力された名前とパスワードは使用されています');
                }
            })
        }
    });

    // 名前
    $('input[name="name"]').change(function(){
        // エラーメッセージを空に
        $('#err-msg-name').empty();
        $('#err-msg-dup').empty();


        // inputの値を取得
        name_val = $(this).val();

        if(name_val == ''){
            $('#err-msg-name').append(name_err);
        }else{
            $('#err-msg-name').empty();
        }
    });

    // パスワード
    $('input[name="password"]').keyup(function(){
        // 空にする
        $('#err-msg-pass').empty();
        $('#err-msg-dup').empty();

        // inputの値を取得
        pass_val = $(this).val();

        // 入力チェック＋パスワードが１６文字以内かどうか
        if(pass_val == ''){
            $('#err-msg-pass').append(pass_err);
        }else if(pass_val.length > 16){
            $('#err-msg-pass').append(pass_err2);
        }else{
            $('#err-msg-pass').empty();
        }
    });

    // 生年月日
    $('input[name="birthday"]').change(function(){
        bir_val = $(this).val();
    })
});


// エスケープ処理
function escapeSelectorString(val){
  return val.replace(/[ !"#$%&'()*+,.\/:;<=>?@\[\\\]^`{|}~]/g, "\\$&");
}