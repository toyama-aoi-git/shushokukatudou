$(function() {
    var date = new Date();
    var timestamp = date.getTime();
    var img = document.getElementsByClassName('load_img')[0];
    img.src = '../img/OP/book_load.gif?' + timestamp;
    var h = $(window).height();
    $('#wrap').css('display','none');
    $('#loader-bg ,#loader').height(h).css('display','block');
});
$(window).load(function () { //全ての読み込みが完了したら実行
    $('#loader-bg').delay(2000).fadeOut(500);
    $('#loader').delay(2000).fadeOut(500);
    $('#wrap').css('display', 'block');
});