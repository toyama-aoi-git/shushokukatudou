<!-- 
    更新　川嶋
    version 1.0
 -->
 <!DOCTYPE html>
<html lang="ja">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <title>イベント詳細</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Zen+Maru+Gothic:wght@300;400;500;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../css/reset.css">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/header.css">
    <link rel="stylesheet" href="../css/modal.css">
    <link rel="stylesheet" href="../css/register.css">
    <link rel="stylesheet" href="../css/event_register.css">
    <link rel="stylesheet" href="../css/button.css">
    <link rel="stylesheet" href="../css/event_change.css">
    <link rel="stylesheet" href="../css/load_reg.css">
    <link rel="stylesheet" href="../css/none.css">
</head>

<body>
<!-- ロード画面 -->
<div id="load-bg">
            <div id="loader">
            <div class="loader">
                <div>
                    <ul>
                    <li>
                        <svg fill="currentColor" viewBox="0 0 90 120">
                        <path d="M90,0 L90,120 L11,120 C4.92486775,120 0,115.075132 0,109 L0,11 C0,4.92486775 4.92486775,0 11,0 L90,0 Z M71.5,81 L18.5,81 C17.1192881,81 16,82.1192881 16,83.5 C16,84.8254834 17.0315359,85.9100387 18.3356243,85.9946823 L18.5,86 L71.5,86 C72.8807119,86 74,84.8807119 74,83.5 C74,82.1745166 72.9684641,81.0899613 71.6643757,81.0053177 L71.5,81 Z M71.5,57 L18.5,57 C17.1192881,57 16,58.1192881 16,59.5 C16,60.8254834 17.0315359,61.9100387 18.3356243,61.9946823 L18.5,62 L71.5,62 C72.8807119,62 74,60.8807119 74,59.5 C74,58.1192881 72.8807119,57 71.5,57 Z M71.5,33 L18.5,33 C17.1192881,33 16,34.1192881 16,35.5 C16,36.8254834 17.0315359,37.9100387 18.3356243,37.9946823 L18.5,38 L71.5,38 C72.8807119,38 74,36.8807119 74,35.5 C74,34.1192881 72.8807119,33 71.5,33 Z"></path>
                        </svg>
                    </li>
                    <li>
                        <svg fill="currentColor" viewBox="0 0 90 120">
                        <path d="M90,0 L90,120 L11,120 C4.92486775,120 0,115.075132 0,109 L0,11 C0,4.92486775 4.92486775,0 11,0 L90,0 Z M71.5,81 L18.5,81 C17.1192881,81 16,82.1192881 16,83.5 C16,84.8254834 17.0315359,85.9100387 18.3356243,85.9946823 L18.5,86 L71.5,86 C72.8807119,86 74,84.8807119 74,83.5 C74,82.1745166 72.9684641,81.0899613 71.6643757,81.0053177 L71.5,81 Z M71.5,57 L18.5,57 C17.1192881,57 16,58.1192881 16,59.5 C16,60.8254834 17.0315359,61.9100387 18.3356243,61.9946823 L18.5,62 L71.5,62 C72.8807119,62 74,60.8807119 74,59.5 C74,58.1192881 72.8807119,57 71.5,57 Z M71.5,33 L18.5,33 C17.1192881,33 16,34.1192881 16,35.5 C16,36.8254834 17.0315359,37.9100387 18.3356243,37.9946823 L18.5,38 L71.5,38 C72.8807119,38 74,36.8807119 74,35.5 C74,34.1192881 72.8807119,33 71.5,33 Z"></path>
                        </svg>
                    </li>
                    <li>
                        <svg fill="currentColor" viewBox="0 0 90 120">
                        <path d="M90,0 L90,120 L11,120 C4.92486775,120 0,115.075132 0,109 L0,11 C0,4.92486775 4.92486775,0 11,0 L90,0 Z M71.5,81 L18.5,81 C17.1192881,81 16,82.1192881 16,83.5 C16,84.8254834 17.0315359,85.9100387 18.3356243,85.9946823 L18.5,86 L71.5,86 C72.8807119,86 74,84.8807119 74,83.5 C74,82.1745166 72.9684641,81.0899613 71.6643757,81.0053177 L71.5,81 Z M71.5,57 L18.5,57 C17.1192881,57 16,58.1192881 16,59.5 C16,60.8254834 17.0315359,61.9100387 18.3356243,61.9946823 L18.5,62 L71.5,62 C72.8807119,62 74,60.8807119 74,59.5 C74,58.1192881 72.8807119,57 71.5,57 Z M71.5,33 L18.5,33 C17.1192881,33 16,34.1192881 16,35.5 C16,36.8254834 17.0315359,37.9100387 18.3356243,37.9946823 L18.5,38 L71.5,38 C72.8807119,38 74,36.8807119 74,35.5 C74,34.1192881 72.8807119,33 71.5,33 Z"></path>
                        </svg>
                    </li>
                    <li>
                        <svg fill="currentColor" viewBox="0 0 90 120">
                        <path d="M90,0 L90,120 L11,120 C4.92486775,120 0,115.075132 0,109 L0,11 C0,4.92486775 4.92486775,0 11,0 L90,0 Z M71.5,81 L18.5,81 C17.1192881,81 16,82.1192881 16,83.5 C16,84.8254834 17.0315359,85.9100387 18.3356243,85.9946823 L18.5,86 L71.5,86 C72.8807119,86 74,84.8807119 74,83.5 C74,82.1745166 72.9684641,81.0899613 71.6643757,81.0053177 L71.5,81 Z M71.5,57 L18.5,57 C17.1192881,57 16,58.1192881 16,59.5 C16,60.8254834 17.0315359,61.9100387 18.3356243,61.9946823 L18.5,62 L71.5,62 C72.8807119,62 74,60.8807119 74,59.5 C74,58.1192881 72.8807119,57 71.5,57 Z M71.5,33 L18.5,33 C17.1192881,33 16,34.1192881 16,35.5 C16,36.8254834 17.0315359,37.9100387 18.3356243,37.9946823 L18.5,38 L71.5,38 C72.8807119,38 74,36.8807119 74,35.5 C74,34.1192881 72.8807119,33 71.5,33 Z"></path>
                        </svg>
                    </li>
                    <li>
                        <svg fill="currentColor" viewBox="0 0 90 120">
                        <path d="M90,0 L90,120 L11,120 C4.92486775,120 0,115.075132 0,109 L0,11 C0,4.92486775 4.92486775,0 11,0 L90,0 Z M71.5,81 L18.5,81 C17.1192881,81 16,82.1192881 16,83.5 C16,84.8254834 17.0315359,85.9100387 18.3356243,85.9946823 L18.5,86 L71.5,86 C72.8807119,86 74,84.8807119 74,83.5 C74,82.1745166 72.9684641,81.0899613 71.6643757,81.0053177 L71.5,81 Z M71.5,57 L18.5,57 C17.1192881,57 16,58.1192881 16,59.5 C16,60.8254834 17.0315359,61.9100387 18.3356243,61.9946823 L18.5,62 L71.5,62 C72.8807119,62 74,60.8807119 74,59.5 C74,58.1192881 72.8807119,57 71.5,57 Z M71.5,33 L18.5,33 C17.1192881,33 16,34.1192881 16,35.5 C16,36.8254834 17.0315359,37.9100387 18.3356243,37.9946823 L18.5,38 L71.5,38 C72.8807119,38 74,36.8807119 74,35.5 C74,34.1192881 72.8807119,33 71.5,33 Z"></path>
                        </svg>
                    </li>
                    <li>
                        <svg fill="currentColor" viewBox="0 0 90 120">
                        <path d="M90,0 L90,120 L11,120 C4.92486775,120 0,115.075132 0,109 L0,11 C0,4.92486775 4.92486775,0 11,0 L90,0 Z M71.5,81 L18.5,81 C17.1192881,81 16,82.1192881 16,83.5 C16,84.8254834 17.0315359,85.9100387 18.3356243,85.9946823 L18.5,86 L71.5,86 C72.8807119,86 74,84.8807119 74,83.5 C74,82.1745166 72.9684641,81.0899613 71.6643757,81.0053177 L71.5,81 Z M71.5,57 L18.5,57 C17.1192881,57 16,58.1192881 16,59.5 C16,60.8254834 17.0315359,61.9100387 18.3356243,61.9946823 L18.5,62 L71.5,62 C72.8807119,62 74,60.8807119 74,59.5 C74,58.1192881 72.8807119,57 71.5,57 Z M71.5,33 L18.5,33 C17.1192881,33 16,34.1192881 16,35.5 C16,36.8254834 17.0315359,37.9100387 18.3356243,37.9946823 L18.5,38 L71.5,38 C72.8807119,38 74,36.8807119 74,35.5 C74,34.1192881 72.8807119,33 71.5,33 Z"></path>
                        </svg>
                    </li>
                    </ul>
                </div><span class="load_p">Loading</span></div>
            </div>
    <!-- ここまで ロード画面-->
    <div id="wrap">
    <header>
        <a href="../Controller/group.php">
            <div class="Arrow-Left"></div>
        </a>

        <h1><?php echo $event[0]['name']; ?></h1>
    </header>
    <main>
        <div >
            <h2>登録内容</h2>
        </div>
        
        <div id="register_table">

            <div class="register_contents">
                <h3 class="table_title">参加者</h3>
                <!-- 参加者 -->
                <p>
                <?php foreach($member_list as $key => $value): ?>
                    <?php foreach($member_id as $key2 => $value2): ?>
                        <?php if($member_id[$key2] == $member_list[$key]["id"]): ?>
                            <?php echo $member_list[$key]['name']; ?>
                        <?php endif; ?>
                    <?php endforeach; ?>
                <?php endforeach; ?>
                </p>
            </div> 
            <div class="register_contents">   
                <!-- コメント -->
                <h3 class="table_title">コメント</h3>
                <p><?php echo $event[0]['comment']; ?></p>
            </div> 
            <div class="register_contents"> 
                <h3 class="table_title">登録写真</h3>
                <div class="registered_photos">
                    <?php if($event_img != ""): ?>
                            <!-- 登録画像 -->
                        <?php foreach($event_img as $key => $value): ?>
                            <di class="registered_photo">
                                <!-- サムネ写真 -->
                                <img class="imgOpen" src="../group/<?php echo $event[0]['group_id']; ?>/event_img/<?php echo $event_id; ?>/<?php echo "group". $event[0]['group_id'] ."_". $event_img[$key]['id'] .".". $event_img[$key]['extension']; ?>" alt="">
                            </di>
                        <?php endforeach; ?>
                    <?php endif; ?>
                    <!-- 登録写真を表示するモーダル -->
                    <div id="easyModal" class="modal">
                        <div class="modal-content">
                            <div class="modal-header">
                                <span class="modalClose">×</span>
                            </div>
                            <div class="modal-body">
                                <form action="./mypage.php" method="POST">
                                    <!-- 会員登録とログインを場合分けする -->
                                    <img class="imgSrc" src="../img/material/mypage.png" alt="">
                                </form>
                            </div>
                        </div>
                    </div>
                    <!-- モーダル終わり -->
                </div>
            </div> 
        </div>
        <div id="attention">
            <p>情報の変更は以下で行ってください</p>
        </div>

        
            <form action="./event_change.php" method="POST" enctype="multipart/form-data">
                <!-- イベント名 -->
                <div class="cp_iptxt">
                    <p id="date">イベント名</p>
                    <input type="text" name="name" autocomplete="off" value="<?php echo $event[0]['name'];?>">
                    <i class="fa fa-user fa-lg fa-fw" aria-hidden="true"></i>
                    <!-- 入力エラー文表示 -->
                    <p class="error"><?php echo $error['name']??''; ?></p>
                    <!-- 送信ボタン -->
                    <div class="buttonCenter"><button id="button" class="button" type="submit" name="na" value="insert">変更</button></div>

                </div>
            </form>
        

            <!-- メンバー選択（セレクトボックス） -->
            <div id="memberSelect" >
                <form action="./event_change.php" method="POST" enctype="multipart/form-data">

                    <p id="date">参加メンバー</p>
                    <div class="boxes">
                        <?php foreach($member_list as $key => $row): ?>
                            <input type="checkbox" name="member[]" value="<?php echo $member_list[$key]['id']; ?>" id="box<?php echo $key; ?>" <?php echo $member_list[$key]['check']; ?>>
                            <label for="box<?php echo $key; ?>"><?php echo $member_list[$key]['name']; ?></label>
                        <?php endforeach; ?>
                    </div>
                    <p class="error_member"><?php echo $error['member']??''; ?></p>
                    <div class="buttonCenter"><button id="button" class="button" type="submit" name="me" value="insert">変更</button></div>
                </form>
            </div>

            <div class="cp_iptxt">
                <form action="./event_change.php" method="POST" enctype="multipart/form-data">
                        <p>コメント：</p>
                        <input type="text" name="comment" value="<?php echo $event[0]['comment']; ?>">
                        <p class="error"><?php echo $error['comment']??''; ?></p>
                        <!-- 送信ボタン -->
                        <div class="buttonCenter"><button id="button" class="button"type="submit" name="co" value="insert">変更</button></div>
                </form>
            </div>

        
        
            <div id="fileSelect">
                <form name="form" action="./event_change.php" method="POST" enctype="multipart/form-data">
                    <p>画像の変更</p>
                    <div class="delete_photos">
                        <?php if($event_img != ""): ?>
                            <!-- 登録画像 -->
                            <?php foreach($event_img as $key => $value): ?>
                                <div class="delete_photo">
                                    <img src="../group/<?php echo $event[0]['group_id']; ?>/event_img/<?php echo $event_id; ?>/<?php echo "group". $event[0]['group_id'] ."_". $event_img[$key]['id'] .".". $event_img[$key]['extension']; ?>" alt="">
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                    <div class="buttonCenter"><button id="button" class="button img_delete">削除</button></div>
                    
                    <div id="fileFlex">
                        <label for="file_upload">
                            <span class="filelabel" title="ファイルを選択">
                                <img src="../img/material/camera-orange-rev.png" width="32" height="26" alt="＋画像">
                                <p>選択</p>
                            </span>
                        </label>
                        <!-- ▽本来の選択フォームは隠す -->
                        <td class="error"><?php echo $error['img']??''; ?></td>
                        <td><input id="file_upload" type="file" name="img[]"  accept="image/*" multiple="multiple"></td>
                        <div id="preview"></div>
                        <div class="buttonCenter"><button id="button" class="button" type="submit" name="im" value="insert" onclick="Form_Submit()">追加</button></div>
                    </div>
                </form>
            </div>


    </main>
    <!-- <p><a href="./group.php">戻る</a></p> -->
    <script src="../js/jquery-3.6.0.min.js"></script>
    <script src="../js/pinchout.js"></script>
    <script src="../js/event_chenge.js"></script>
    <script src="../js/event_register.js"></script>
    <script src="../js/load_change.js"></script>
</body>

</html>