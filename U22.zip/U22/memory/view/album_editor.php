<!DOCTYPE html>
<html lang="ja">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <link rel="stylesheet" href="../css/reset.css">
    <link rel="stylesheet" href="../css/style.css">
    <!--<link rel="stylesheet" type="text/css" href="./css/style.css">-->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Zen+Maru+Gothic:wght@300;400;500;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="../css/album_editor.css">
    <link rel="stylesheet" type="text/css" href="../css/album_all.css">
    <link rel="stylesheet" type="text/css" href="../css/button.css">
    <link rel="stylesheet" href="../css/album_shadow.css">
    <link rel="stylesheet" type="text/css" href="../css/style_text.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css">
    <link rel="stylesheet" href="../css/color.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css">
    <link rel="stylesheet" href="https://unpkg.com/@sjmc11/tourguidejs/dist/css/tour.min.css">
    <link rel="stylesheet" href="../css/chutorial_btn.css">

    <title>アルバム作成</title>
    <style>
        .sreg {
            text-align: right;
            margin-right: 1rem;
        }
    </style>
</head>

<body>
    <div id="album">
        <div id="flipbook" data-tg-order=5 data-tg-tour='<img src="../img/chutorial.png"><br>各ページの左上の左ボタンで背景色変更<br>右ボタンで画像を表示できます'>
            <!-- 表紙 -->
            <div class=" hll">


                <div class="add_media absolute album_top_media" style="z-index: 1; top: 62.3873px; left: 64.0926px;">
                    <h3 class="add_text"><?php echo $_SESSION['title']; ?></h3>
                </div>
                <button type="button" id="color" class="button add-color-btn add-group "><img src="../img/material/paint.png" width="20" alt=""></button>
                <div class="album_top_media" style="z-index: 0; position: absolute ">
                    <img class="album_top" src="../img/album_top.png" alt="">
                </div>
            </div>
            <!-- 表紙裏ー1ページ目 -->


            <?php for ($i = 0; $i < $page; $i++) {  ?>
                <div class=" hll">
                    <button id="color" type="button" class="add-group add-color-btn button"><img src="../img/material/paint.png" width="20" alt=""></button>
                    <button id="photo" type="button" class="add-group add-media-btn none button"><img src="../img/material/img2.png" width="20" alt=""></button>
                </div>
            <?php } ?>


            <div class=" hll">
                <button id="color" type="button" class="add-group add-color-btn button"><img src="../img/material/paint.png" width="20" alt=""></button>
                <button id="photo" type="button" class="add-group add-media-btn none button"><img src="../img/material/img2.png" width="20" alt=""></button>
            </div>
        </div>
    </div>

    <div id="menu_buttons">
        <div>
            <h2>編集モード</h2>
            <div data-tg-order=4 data-tg-tour="編集モードを切り替えられます<br>(編集モードになるとページめくりが出来なくなり変更の適用が行えます)">
                <button class="button" type="button" id="disable-btn">ON</button>
                <button class="button" type="button" id="enables-btn">OFF</button>
            </div>
        </div>
        <div>
            <h2>ページの背景色</h2>
            <form data-tg-order=3 data-tg-tour="変更する背景色を選択できます">
                <input class="color" data-jscolor="{}" readonly="readonly" />
            </form>
        </div>
    </div>

    <div class="toggle">
        <label data-tg-order=1 data-tg-tour="画像とスタンプを変更できます" class="switch">
            <input id="toggle_switch" type="checkbox">
            <span class="slider"></span>
        </label>
        <div class="sreg">
            <div class="reg">
                <label> 画像角度</label>
                <input id="reg" type="range" min='0' max='360' value="0">
            </div>
            <div>
                <label> 画像サイズ</label>
                <input id="size" type="range" min='40' max='160' value="70">
            </div>
        </div>
    </div>


    <div data-tg-order=2 data-tg-tour="選択したイベントの写真一覧<br>もしくはスタンプ一覧が表示されます" id="photo_in" class='img_stacks'>

        <?php

        foreach ($data as $k => $v) {
            $id = $v['id'];
            $extension = $v['extension'];
            $event_id = $v['event_id'];
            echo '<div class="' . 'display_img' . '"' . "><img class='img_stack' src='../group/$group_id/event_img/$event_id/group" . $group_id . "_" . $id . ".$extension' alt=''></div>";
        }
        ?>


    </div>


    <div id="stamp_in" class='img_stacks'>
        <div class="display_img"><img class="img_stack" src="../img/stamp/1369.gif"></div>
        <div class="display_img"><img class="img_stack" src="../img/stamp/1387.gif"></div>
        <div class="display_img"><img class="img_stack" src="../img/stamp/2243.gif"></div>
        <div class="display_img"><img class="img_stack" src="../img/stamp/sun.gif"></div>
        <div class="display_img"><img class="img_stack" src="../img/stamp/laughing.gif"></div>
        <div class="display_img"><img class="img_stack" src="../img/stamp/balloon.gif"></div>
        <div class="display_img"><img class="img_stack" src="../img/stamp/23591185.png"></div>
        <div class="display_img"><img class="img_stack" src="../img/stamp/23593232.png"></div>
        <div class="display_img"><img class="img_stack" src="../img/stamp/23593273.png"></div>
        <div class="display_img"><img class="img_stack" src="../img/stamp/23563400.png"></div>
        <div class="display_img"><img class="img_stack" src="../img/stamp/285.png"></div>
        <div class="display_img"><img class="img_stack" src="../img/stamp/1411.png"></div>
        <div class="display_img"><img class="img_stack" src="../img/stamp/1745.png"></div>
        <div class="display_img"><img class="img_stack" src="../img/stamp/10068.png"></div>
        <div class="display_img"><img class="img_stack" src="../img/stamp/14262.png"></div>
        <div class="display_img"><img class="img_stack" src="../img/stamp/23511.png"></div>
        <div class="display_img"><img class="img_stack" src="../img/stamp/23751.png"></div>
        <div class="display_img"><img class="img_stack" src="../img/stamp/331433.png"></div>
        <div class="display_img"><img class="img_stack" src="../img/stamp/23574262.png"></div>
        <div class="display_img"><img class="img_stack" src="../img/stamp/23580917.png"></div>
        <div class="display_img"><img class="img_stack" src="../img/stamp/23598727.png"></div>
        <div class="display_img"><img class="img_stack" src="../img/stamp/heart.png"></div>

    </div>

    <!-- ​   チュートリアルボタン    -->
    ​ <p id="chutorial_btn"><button class="button"></button></p>



    <a id="album_edit_end" href="../Controller/album_list.php">
        <div class="button">編集完了</div>
    </a>
</body>
<script src='../js/jquery-3.6.0.min.js'></script>
<script src="../js/jscolor.min.js"></script>
<script src='../js/album_editor.js'></script>
<script src='../js/add_img.js'></script>
<script src='../js/img_move.js'></script>
<script src='../js/text.js'></script>
<script src="https://unpkg.com/@sjmc11/tourguidejs/dist/tour.js"></script>
<!-- アルバムのサイズ変更角度変更js -->
<script src="../js/album_img_size.js"></script>
<script src='../js/pinchout.js'></script>
<script src="../js/chutorial.js"></script>
<script src='../js/turn.js'></script>
<script type="text/javascript">
    $("#flipbook").turn({
        width: 400,
        height: 300,
        autoCenter: true
    });

    var js_php = [
        <?php foreach ($ids as $key => $value) { ?>
            <?php if ($key == 0) { ?>
                <?php echo $value; ?>
            <?php } else { ?>
                <?php echo ',' . $value; ?>
            <?php } ?>
        <?php }  ?>
    ];
</script>


</html>