<!-- 
    更新　西谷⇒籾木
    version 1.0
 -->
 <!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <title>アルバム作成</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Zen+Maru+Gothic:wght@300;400;500;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../css/reset.css">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/album_shadow.css">
    <link rel="stylesheet" href="../css/header.css">
    <link rel="stylesheet" href="../css/album_edit.css">
    <link rel="stylesheet" href="../css/selectbox.css">
    <link rel="stylesheet" href="../css/button.css">
</head>
<body>
    <header>
        <a href="../Controller/album_list.php">
            <div class="Arrow-Left"></div>
        </a>
        <div id="title">
            <h2>アルバム作成</h2>
        </div>
    </header>

    <main>
        <div>
            <h2>アルバムタイトル</h2>
            <p id="title_err"></p>
            <div id="title">
                <input type="text" name="album_title" value="" placeholder="タイトル">
            </div>
            <h2>イベント一覧</h2>
            <p id="error"></p>
            <form action="">
                <div class="boxes">
                    <!-- イベント表示ループ -->
                        <?php foreach ($data as $key => $value) { ?>
                            <div class="event_box">
                                
                                <input  class="checks" type="checkbox" name="member[]" value="<?php echo $value["name"]; ?>" id="box<?php echo $key; ?>">
                                <label id="<?php echo($value["id"]) ?>" class="img_stack" for="box<?php echo $key; ?>">
                                    <!-- 表示項目 -->
                                    <div class="border_box">
                                        <!-- イベント名 -->
                                        <h2><?php echo $value['name']; ?></h2>
                                        <!-- 年月 -->
                                        <h3>日付：<?php echo $value['date']; ?></h3>

                                        <!-- 画像 -->
                                        <h3>登録写真</h3>
                                        <div class="registed_photos">
                                            <?php foreach($list as $value){ ?>
                                                <?php if(COUNT($value[$key]) >= 2){ ?>
                                                    <div class="registed_photo"><img src="../group/<?php echo $_SESSION['group_id']; ?>/event_img/<?php echo $value[$key][0]['event_id']; ?>/group<?php echo $_SESSION['group_id']; ?>_<?php echo $value[$key][0]['id']; ?>.<?php echo $value[$key][0]['extension']; ?>" alt=""></div>
                                                    <div class="registed_photo"><img src="../group/<?php echo $_SESSION['group_id']; ?>/event_img/<?php echo $value[$key][1]['event_id']; ?>/group<?php echo $_SESSION['group_id']; ?>_<?php echo $value[$key][1]['id']; ?>.<?php echo $value[$key][1]['extension']; ?>" alt=""></div>
                                                <?php }elseif(COUNT($value[$key]) == 1){ ?>
                                                    <div class="registed_photo"><img src="../group/<?php echo $_SESSION['group_id']; ?>/event_img/<?php echo $value[$key][0]['event_id']; ?>/group<?php echo $_SESSION['group_id']; ?>_<?php echo $value[$key][0]['id']; ?>.<?php echo $value[$key][0]['extension']; ?>" alt=""></div>
                                                <?php }else{ ?>
                                                    <div class="registed_photo">画像がありません</div>
                                                <?php } ?>
                                            <?php } ?>
                                        </div>
                                    </div>
                                </label>
                            </div>
                        <?php } ?>
                    <!--  -->
                </div>
            </form>
        </div>

    <div class="custom-select">
    <label for="page" class="label select-1"><span class="selection-choice">ページ数を選んでください</span> </label>
    <select id="page" class="select" name="page">
        <option hidden>選択してください</option>
        <option value="2">2ページ</option>
        <option value="4">4ページ</option>
        <option value="6">6ページ</option>
        <option value="8">8ページ</option>
        <option value="10">10ページ</option>
        <option value="12">12ページ</option>
        <option value="14">14ページ</option>
        <option value="16">16ページ</option>
        <option value="18">18ページ</option>
        <option value="20">20ページ</option>
        <option value="22">22ページ</option>
        <option value="24">24ページ</option>
        <option value="26">26ページ</option>
        <option value="28">28ページ</option>
        <option value="30">30ページ</option>
    </select>
    </div>

    <div id="button_box">
    <button id="" class="button add_id">アルバム作成</button>
    </div>
    </main>
    <script src="../js/jquery-3.6.0.min.js"></script>
    <script src="../js/swiper-bundle.min.js"></script>
    <script src="../js/pinchout.js"></script>
    <script src="../js/album_edit.js"></script>
</body>
</html>