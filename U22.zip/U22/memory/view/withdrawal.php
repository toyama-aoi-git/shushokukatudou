<!-- 
    更新　籾木
    version 1.1
 -->
 <!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <title></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Zen+Maru+Gothic:wght@300;400;500;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../css/reset.css">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/header.css">
    <link rel="stylesheet" href="../css/button.css">
    <!-- このページのcss -->
    <link rel="stylesheet" href="../css/withdrawal.css">
</head>
<body>
    <!-- 上部 -->
    <header>
        <a href="./mypage.php">
            <div class="Arrow-Left"></div>
        </a>
        <span id="headerText">退会確認</span>
    </header>

    <main>
        <!-- <h2>退会確認</h2> -->
        <!-- ボタン -->
        <div id="text">
            <p>今までの思い出が消えてしまいます</p>
            <p>よろしいですか？</p>
        </div>
        <div id="link">
            <p class="button taikai"><a href="./withdrawal.php?with=withdrawal">退会する</a></p>
            <p class="button"><a href="./mypage.php" >戻る</a></p>
        </div>
    </main>






    <script src="../js/pinchout.js"></script>
</body>
</html>