<!-- 
    更新　籾木
    version 0.0
 -->
 <!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <title></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Zen+Maru+Gothic:wght@300;400;500;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../css/reset.css">
    <link rel="stylesheet" href="../css/album_shadow.css">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/button.css">
    <!-- <link rel="stylesheet" href="../css/header.css"> -->
    <!-- 専用css -->
    <link rel="stylesheet" href="../css/album_detail.css">

    <!-- モーダル用css -->
    <link rel="stylesheet" href="../css/modal.css">
    <!-- ロード用css -->
    <link rel="stylesheet" href="../css/load_album.css">
    
</head>
<body>
    <!-- ロード画面 -->
    <div class="bg">
        <div id="loader">
            <img src="../img/phone.png" alt="" class="rotate" width="80px" height="auto">
            <p class="rote">画面固定をして<br>横画面でご覧ください！</p>
        </div>
    </div>
    <!-- ロード画面ここまで -->
    <header>
        <a href="./album_list.php">
            <div class="Arrow-Left"></div>
        </a>
    </header>

    <div id="d_frame">
        <iframe src="./album_brow.php" 
            allowtransparency="true"
            frameborder="0"
            id="frame"
        >
    </iframe>

    </div>
    <!-- ボタン -->
    <div class="button_menu">
        <!-- アルバム削除ボタン -->
        <div>
            <button class="button" id="modalOpen" class="modalButton">削除</button>
        </div>
        <!-- アルバム編集ボタン -->
        <div>
            <a href="./album_detail.php?editor" class="button">編集</a>
        </div>
    </div>

    <!-- モーダル -->
    <div id="easyModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <span class="modalClose">×</span>
            </div>
            <div class="modal-body">
                <p>
                    アルバムを削除します。<br>
                    本当によろしいですか？
                </p>
                <form action="./album_detail.php" method="POST">
                    <button class="button" type="submit" name="delete">削除する</button>
                </form>
            </div>
        </div>
    </div>


    <script src="../js/jquery-3.6.0.min.js"></script>
    <script src="../js/turn.js"></script>
    <script src="../js/pinchout.js"></script>
    <script src="../js/album_detail.js"></script>
    <script src="../js/modal.js"></script>
</body>
</html>