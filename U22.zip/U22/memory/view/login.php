<!-- 
    更新　川嶋
    version 0.0
-->

<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <title>ログイン</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Zen+Maru+Gothic:wght@300;400;500;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../css/reset.css">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/header.css">
    <link rel="stylesheet" href="../css/register.css">
    <link rel="stylesheet" href="../css/button.css">
    
    <link rel="stylesheet" href="../css/login.css">
</head>
<body>
    <header>
        <a href="./OP.php">
            <div class="Arrow-Left"></div>
        </a>
        <span id="headerText">ログイン</span>    
    </header>

    <main>
    <!-- 画像が切り替わる部分 -->
    <div id="changeImage"></div>


    <!-- ログイン失敗エラー文 -->
    <?php if(isset($back_error)): ?>
        <p class="loginError"><?php echo $back_error; ?></p>
    <?php endif; ?>


    <!-- 入力ボックス -->
    
        <form action="./login.php" method="POST">
            <!-- ログインID -->                                      <!-- ↓↓↓↓ 値保持処理 ↓↓↓↓ -->
            <div class="cp_iptxt">
                <input type="text" id="name" placeholder="名前" name="name" value="<?php echo isset($back_name)?$back_name:''; ?>" autocomplete="off">
                <i class="fa fa-envelope fa-lg fa-fw" aria-hidden="true"></i>
                <!-- 入力エラー文表示 -->
                    <p class="error"><?php echo $error['name']??''; ?></ｐ>
            </div>

            <!-- パスワード -->
            <div class="cp_iptxt">
                <input type="password" id="passClick" placeholder="パスワード" name="password" value="" autocomplete="off">
                <p id="passEye"><img id="eyeImg" src="../img/material/eye-slash.svg" alt=""></p>
                <i class="fa fa-envelope fa-lg fa-fw" aria-hidden="true"></i>
                <!-- 入力エラー文表示 -->
                    <p class="error"><?php echo $error['pass']??''; ?></p>
            </div>

            <!-- 送信ボタン -->
            <div class="btn_area">
                <button type="submit" name="state" class="button" value="insert">確認</button>
            </div>
        </form>
    </main>

<script src="../js/jquery-3.6.0.min.js"></script>
<script src="../js/register.js"></script>
<script src="../js/pinchout.js"></script>

</body>
</html>