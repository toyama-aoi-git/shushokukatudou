<!-- 
    更新　籾木
    version 1.1
 -->
 <!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <title>会員登録</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Zen+Maru+Gothic:wght@300;400;500;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../css/reset.css">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/button.css">
    <link rel="stylesheet" href="../css/register.css">
    <link rel="stylesheet" href="../css/modal.css">
    <link rel="stylesheet" href="../css/header.css">
    <!-- <link rel="stylesheet" href="../css/style.css"> -->
</head>
<body>

    <!-- 上部 -->
    <header>
        <a href="./OP.php">
            <div class="Arrow-Left"></div>
        </a>
        <span id="headerText">会員登録</span>    
    </header>


    <!-- メインの登録部分 -->
    <main>

            
        <!-- 画像が切り替わる部分 -->
        <div id="changeImage"></div>

        <div id="attention">
            <p>お客様の情報を登録してください</p>
            <p>*必須項目</p>
        </div>

        <form name="form" action="./register.php" method="post" enctype="multipart/form-data">
            <!-- 氏名 -->
            <div class="cp_iptxt">
                <p class="hissu">*</p>
                <input type="text" id="name" autocomplete="off" placeholder="お名前" name="name" value="">
                <i class="fa fa-user fa-lg fa-fw" aria-hidden="true"></i>
                <!-- エラー文 -->
                <p id="err-msg-name" class="error"></p>

                <?php if(isset($err['name'])){ ?>
                    <p class="error"><?php echo $err['name']; ?></ｐ>
                <?php } ?>
            </div>

            <!-- パスワード -->
            <div class="cp_iptxt">
                <p class="hissu">*</p>
                <input type="password" id="passClick" placeholder="パスワード" name="password" autocomplete="off">
                <p id="passEye"><img id="eyeImg" src="../img/material/eye-slash.svg" alt=""></p>
                <i class="fa fa-envelope fa-lg fa-fw" aria-hidden="true"></i>
                <!-- エラー文 -->
                <p id="err-msg-pass" class="error"></p>
            </div>

            <!-- 生年月日 -->
            <div id="birth">
                <p>　生年月日</p>
                <label>
                    <input type="date" id="birthday" name="birthday" value="<?php echo isset($_SESSION['birthday'])?$_SESSION['birthday']:''; ?>">
                </label>
                <p>
                    <span>※設定後変更できません</span><br>
                    <span>※生年月日はあとでも設定できます</span>
                </p>
                <p id="err-msg-dup"></p>
            </div>

        </form>

            <!-- モーダルウィンドウ -->
            <div class="btn_area">
                <button id="modalOpen" class="button">登録内容の確認</button>
            </div>
            <div id="easyModal" class="modal">
                <div class="modal-content">
                    <div class="modal-header">
                        <span class="modalClose">×</span>
                    </div>
                    <div class="modal-body">
                        <!-- 登録内容を表示 -->
                        <table>
                            <tr id="name_row">
                                <td class="table_sec_title">氏名:</td>
                                <td></td>
                            </tr>
                            <tr id="password_row">
                                <td class="table_sec_title">パスワード:</td>
                                <td></td>
                            </tr>
                            <tr id="birthday_row">
                                <td class="table_sec_title">生年月日:</td>
                                <td></td>
                            </tr>
                        </table>
                        <button name="start" value="register" class="button">会員登録</button><br>
                    </div>
                </div>
            </div>
    </main>
    <footer>

    </footer>

    <script src="../js/jquery-3.6.0.min.js"></script>
    <script src="../js/register.js"></script>
    <script src="../js/pinchout.js"></script>
    <script src="../js/validation.js"></script>
</body>
</html>