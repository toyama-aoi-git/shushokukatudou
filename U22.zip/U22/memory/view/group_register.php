<!-- 
    更新　川嶋
    version 1.0
 -->
 <!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <title></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Zen+Maru+Gothic:wght@300;400;500;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../css/reset.css">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/register.css">
    <link rel="stylesheet" href="../css/button.css">
    <link rel="stylesheet" href="../css/group_register.css">
    <link rel="stylesheet" href="../css/header.css">
</head>
<body>
    <!-- 上部 -->
    <header>
        <a href="./group_list.php">
            <div class="Arrow-Left"></div>
        </a>
        <span id="headerText">グループ作成</span>    
    </header>



    <!-- テキストボックス部分 -->
    <main>
        <!-- 画像が切り替わる部分 -->
        <div id="changeImage"></div>

        <div id="attention">
            <p>グループの情報を登録してください</p>
            <p>*必須項目</p>
        </div>

        <form action="./group_register.php" method="POST"enctype = "multipart/form-data">

            <!-- 氏名 -->
            <div class="cp_iptxt">
                <p class="hissu">*</p>
                <input type="text" id="name" placeholder="グループ名" name="name"value="<?php echo isset($back_name)?$back_name:''; ?>" autocomplete="off">
                <i class="fa fa-user fa-lg fa-fw" aria-hidden="true"></i>
                <!-- 入力エラー文表示 -->
                    <p class="error"><?php echo $error['name']??''; ?></p>
            </div>


            <!-- アイコン -->
            <div id="fileSelect">
                <p id="icon">アイコンを選択してください</p>
                <div id="fileFlex">
                    <label for="file_upload">
                        <span id="img" class="filelabel" title="ファイルを選択">
                            <img src="../img/material/camera-orange-rev.png" width="32" height="26" alt="＋画像">
                            <p>選択</p>
                        </span>
                        <!-- ▽本来の選択フォームは隠す -->
                        <input type="file" name="img" id="file_upload" autocomplete="off" accept="image/*">
                    </label>
                    <div id="preview"></div>
                </div>
            </div>


            <!-- <p>アイコン<input type="file" name="img"></p> -->

            <!-- 送信ボタン -->
            <div class="btn_area">
                <button type="submit" class="button" name="state" value="insert">グループ作成</button>
            </div>
        </form>
    </main>

    <script src="../js/jquery-3.6.0.min.js"></script>
    <script src="../js/event_register.js"></script>
    <script src="../js/pinchout.js"></script>
    <script src="../js/register.js"></script>
</body>
</html>