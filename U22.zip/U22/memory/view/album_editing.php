<!DOCTYPE html>
<html lang="ja">
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
<link rel="stylesheet" href="../css/reset.css">
<link rel="stylesheet" href="../css/style.css">
<!--<link rel="stylesheet" type="text/css" href="./css/style.css">-->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Zen+Maru+Gothic:wght@300;400;500;700;900&display=swap" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="../css/album_editing.css">
<link rel="stylesheet" type="text/css" href="../css/album_all.css">
<link rel="stylesheet" type="text/css" href="../css/button.css">
<link rel="stylesheet" href="../css/album_shadow.css">
<link rel="stylesheet" type="text/css" href="../css/style_text.css">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css">
<link rel="stylesheet" href="../css/color.css">
<style>
    .sreg{
        text-align: right;
        margin-right: 1rem;
    }
</style>


<title>アルバム編集</title>
 </head>
<body>
    <main>
        <div id="contena"></div>

        <div id="menu_buttons">
            <div>
                <h2>編集モード</h2>
                <button class="button"type="button" id="disable-btn">ON</button>
                <button class="button" type="button" id="enables-btn">OFF</button>
            </div>
        <div>

        <h2>ページの背景色</h2>
        <form>       
            <input class="color" data-jscolor="{position:'bottom', height:80, previewPadding:10, backgroundColor:'#333',paletteCols:11, hideOnPaletteClick:true}">
        </form>
    </div>
</div>

<div class="toggle">
    <label data-tg-order=1  data-tg-tour="画像とスタンプを変更できます" class="switch">
        <input  id="toggle_switch" type="checkbox">
        <span class="slider"></span>
    </label>
    <div class="sreg">
        <div class="reg">
            <label> 画像角度</label>
                <input id="reg" type="range" min='0' max='360' value="0">
        </div>
        <div>
            <label> 画像サイズ</label>
                <input id="size" type="range" min='40' max='160' value="70">
        </div>
    </div>
</div>

        <div id="photo_in" class ='img_stacks'>
            <?php
            foreach ($data as $k => $v) {
                $id = $v['id'];
                $extension = $v['extension'];
                $event_id = $v['event_id'];
                echo '<div class="' . 'display_img' . '"' . "><img class='img_stack' src='../group/$group_id/event_img/$event_id/group" . $group_id . "_" . $id . ".$extension' alt=''></div>";
            }   
            ?>
        </div>
        <div id="stamp_in" class ='img_stacks'>
    <div class="display_img"><img class="img_stack" src="../img/stamp/1369.gif"></div>
    <div class="display_img"><img class="img_stack" src="../img/stamp/1387.gif"></div>
    <div class="display_img"><img class="img_stack" src="../img/stamp/2243.gif"></div>
    <div class="display_img"><img class="img_stack" src="../img/stamp/sun.gif"></div>
    <div class="display_img"><img class="img_stack" src="../img/stamp/laughing.gif"></div>
    <div class="display_img"><img class="img_stack" src="../img/stamp/balloon.gif"></div>
    <div class="display_img"><img class="img_stack" src="../img/stamp/23591185.png"></div>
    <div class="display_img"><img class="img_stack" src="../img/stamp/23593232.png"></div>
    <div class="display_img"><img class="img_stack" src="../img/stamp/23593273.png"></div>
    <div class="display_img"><img class="img_stack" src="../img/stamp/23563400.png"></div>
    <div class="display_img"><img class="img_stack" src="../img/stamp/285.png"></div>
    <div class="display_img"><img class="img_stack" src="../img/stamp/1411.png"></div>
    <div class="display_img"><img class="img_stack" src="../img/stamp/1745.png"></div>
    <div class="display_img"><img class="img_stack" src="../img/stamp/10068.png"></div>
    <div class="display_img"><img class="img_stack" src="../img/stamp/14262.png"></div>
    <div class="display_img"><img class="img_stack" src="../img/stamp/23511.png"></div>
    <div class="display_img"><img class="img_stack" src="../img/stamp/23751.png"></div>
    <div class="display_img"><img class="img_stack" src="../img/stamp/331433.png"></div>
    <div class="display_img"><img class="img_stack" src="../img/stamp/23574262.png"></div>
    <div class="display_img"><img class="img_stack" src="../img/stamp/23580917.png"></div>
    <div class="display_img"><img class="img_stack" src="../img/stamp/23598727.png"></div>
    <div class="display_img"><img class="img_stack" src="../img/stamp/heart.png"></div>

</div>
<a id="album_editing_end" href="../Controller/album_detail.php"><div class="button">編集完了</div></a>


    </main>
    <script src="../js/jquery-3.6.0.min.js"></script>
    <script src="../js/jscolor.min.js"></script>
    <script src='../js/album_editing.js'></script>
    <script src='../js/add_img.js'></script>
    <script src='../js/img_move.js'></script>
    <script src='../js/turn.js'></script>
    <script src='../js/text.js'></script>
    <script src="../js/album_img_size.js"></script>
    <script src="../js/pinchout.js"></script>
    <script type="text/javascript">
        
        let js_php_g = <?php echo $json_group_id; ?>;
        let js_php_a = <?php echo $json_album_id; ?>;
        var js_php = [
            <?php foreach($ids as $key => $value){ ?>
                <?php if($key == 0){ ?>
                    <?php echo $value; ?>
                <?php }else{ ?>
                    <?php echo ','.$value; ?>
                <?php } ?>
            <?php }  ?> ];
    </script>   
</body>
</html>