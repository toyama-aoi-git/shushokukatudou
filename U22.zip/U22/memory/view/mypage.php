<!-- 
    更新　川嶋
    version 1.0
 -->
 <!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <title>マイページ</title>
    <!-- googleフォント -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Zen+Maru+Gothic:wght@300;400;500;700;900&display=swap" rel="stylesheet">
    <!-- 標準のcss -->
    <link rel="stylesheet" href="../css/reset.css">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/button.css">
    <!-- header用css -->
    <link rel="stylesheet" href="../css/header.css">
    <!-- モーダル用css -->
    <link rel="stylesheet" href="../css/modal.css">
    <!-- マイページ専用css -->
    <link rel="stylesheet" href="../css/mypage.css">
    <!-- <link rel="stylesheet" href="../css/Information_change.css"> -->
</head>
<body>
    <!-- 上部 -->
    <header>
        <a href="./group_list.php">
            <div class="Arrow-Left"></div>
        </a>
        <span id="headerText">マイページ</span>
        <!-- ログアウトと退会をモーダルで表示 -->
        <button id="modalOpen" class="modalButton">・・・</button>
    </header>

    <div id="easyModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <span class="modalClose">×</span>
            </div>
            <div class="modal-body">
                <form action="./mypage.php" method="POST">
                    <!-- 会員登録とログインを場合分けする -->
                    <button type="submit" name="logout" value="logout" class="button">ログアウト</button><br>
                    <p id="dalete"><a href="../Controller/withdrawal.php" class="button">退会</a></p>
                </form>
            </div>
        </div>
    </div>



    <main>
        <!-- アイコン表示 -->
        <p id="icon"><img src="<?php echo $icon; ?>" class="<?php echo $class; ?>" alt=""></p>


        <div class="topContent">
            <p><?php echo $name; ?></p>
            <p>誕生日：<?php echo $birthday; ?></p>
        </div>


        <div id="attention">
            <p>情報の変更は以下で行ってください</p>
        </div>

        <!-- 氏名 -->
        <div class="miniContent">
            <form class="form" action="./mypage.php" method="POST"　enctype="multipart/form-data">
                <button class="buttonImg">
                    <img src="../img/material/name.png" alt="">
                </button>
                <input class="input" placeholder="お名前" type="text" autocomplete="off" name="name" value="<?php echo isset($name)?$name:''; ?>">
                <!-- 送信ボタン -->
                <button class="buttonBlock" type="submit" name="state_name" value="name">変更</button>
            </form>
            <!-- 入力エラー文表示 -->
            <p class="error"><?php echo $error['name']??''; ?></p>
        </div>

        <!-- パスワード -->
        <div class="miniContent">
            <form class="form" action="./mypage.php" method="POST"　enctype="multipart/form-data">
                <button class="buttonImg">
                    <img src="../img/material/password.png" alt="">
                </button>
                <input id="passClick" class="input" placeholder="パスワード" type="password" autocomplete="off" name="password" value="<?php echo isset($password)?$password:'';?>">
                <!-- 目 -->
                <p id="passEye">
                    <img id="eyeImg" src="../img/material/eye-slash.svg" alt="">
                </p>
                <!-- 送信ボタン -->
                <button class="buttonBlock" type="submit" name="state_pass" value="name">変更</button>
            </form>
            <!-- 入力エラー文表示 -->
            <p class="error"><?php echo $error['pass']??''; ?></p>
        </div>

        <!-- アイコン -->
        <form action="./mypage.php" method="POST"enctype="multipart/form-data">
            <div id="fileSelect">
                <div id="fileFlex">
                    <!-- <p id="icon_text">アイコンを変更</p> -->
                    <label for="file_upload">
                        <div class="filelabel" title="ファイルを選択">
                            <img src="../img/material/camera.png" width="32"  alt="＋画像">
                            <p>アイコンを選択してください</p>
                        </div>
                        <!-- ▽本来の選択フォームは隠す -->
                        <input type="file" id="file_upload" name="img" autocomplete="off" accept="image/*">
                    </label>
                    <!-- 送信ボタン -->
                    <button class="iconButton" type="submit" name="state_file" value="icon">変更</button>
                </div>
            </div>
            <div id="preview"></div>
        </form>


        <!-- 誕生日 -->
        <?php if($birthday == '未設定'): ?>
            <form action="./mypage.php" method="POST"　enctype="multipart/form-data">
                <div id="birth">
                    <!-- <p id="date"><span class="hissu">*</span>日付</p> -->
                    <label>
                        <input type="text" placeholder="誕生日を入力してください" id="birthday" name="birthday" value="<?php echo isset($_SESSION['birthday'])?$_SESSION['birthday']:''; ?>">
                    </label>
                    <!-- 送信ボタン -->
                    <button class="dateButton" type="submit" name="state_birth" value="birth">変更</button>
                </div>
            </form>
        <?php endif; ?>


    </main>


    <script src="../js/jquery-3.6.0.min.js"></script>
    <script src="../js/modal.js"></script>
    <script src="../js/pinchout.js"></script>
    <script src="../js/register.js"></script>
    <script src="../js/event_register.js"></script>
    <script src="../js/mypage.js"></script>
</body>
</html>