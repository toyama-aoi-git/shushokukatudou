<!-- 
    更新　田中
    version 0.0
 -->
 <!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <title></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Zen+Maru+Gothic:wght@300;400;500;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../css/reset.css">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/button.css">
    <!-- <link rel="stylesheet" href="../css/header.css"> -->
    <link rel="stylesheet" href="../css/notification.css">
</head>
<body>

    <form action="./notification.php" method="POST">
        <!-- チェックボックス -->
        <?php foreach($list as $key => $val){ ?>
            <p class="check"><?php echo isset($val['comment'])?"<label class='checkBox'>" .$val['comment'] . " <input type='checkbox' name='id_".$key. "' value='" . $val['id'] . "'></label>":$val['not']; ?></p>
            <?php } ?>
        <!-- 削除ボタン -->
        <?php echo !isset($list[0]['not'])?"<button class='button'>削除</button>":"";?>
    </form>


<script src="../js/pinchout.js"></script>
</body>
</html>