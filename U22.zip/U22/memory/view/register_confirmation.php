<!-- 
    更新　籾木
    version 0.0
 -->
 <!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <title></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Zen+Maru+Gothic:wght@300;400;500;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../css/reset.css">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/register_confirmation.css">
    <link rel="stylesheet" href="../css/header.css">
</head>

<body>
    <p id="check">以下の内容で送信してもよろしいですか？</p>
    <table>
        <tr>
            <td>氏名</td>
            <td><?php echo $_SESSION['name']; ?></td>
        </tr>
        <!-- <tr>
            <td>メールアドレス</td>
            <!-- <td><?php echo $_SESSION['mail']; ?></td> -->
        <!-- </tr> -->
        <tr>
            <td>パスワード</td>
            <td><?php echo $password; ?></td>
        </tr>
        <tr>
            <td>生年月日</td>
            <td><?php echo $_SESSION['birthday'] != ''?$birthday[0].'年'.$birthday[1].'月'.$birthday[2].'日':'未登録'; ?></td>
        </tr>
    </table>


    <!-- 会員登録完了画面に遷移 -->
    <p><a href="./register_confirmation.php?id=insert">登録</a></p>

    <!-- 会員登録画面に遷移 -->
    <p><a href="./register.php?id=back">戻る</a></p>
    <script src="../js/pinchout.js"></script>

</body>
</html>